#!/bin/bash
# run_milestone1.sh - run the Milestone 1 pipeline: environment record, test file, trace, benchmark.
# Usage: DATADIR=/folder/on/local/ssd CPUS=34 ./run_milestone1.sh
# Optional settings: SIZE_MB (1024), RATE (20000), DURATION (10), SEED (1), DEPTH (32), DIRECT (1)
set -e

DATADIR=${DATADIR:?set DATADIR to a folder on the local SSD}
SIZE_MB=${SIZE_MB:-1024}
RATE=${RATE:-20000}
DURATION=${DURATION:-10}
SEED=${SEED:-1}
DEPTH=${DEPTH:-32}
DIRECT=${DIRECT:-1}
CPUS=${CPUS:-}

STAMP=$(date +%Y%m%d_%H%M%S)
OUT=results/$STAMP
mkdir -p "$OUT" "$DATADIR"
echo "Host: $(hostname)   Output: $OUT"

# 1. environment record (Sirisha's script writes run_metadata.txt)
bash record_env.sh >/dev/null
{ echo; echo "--- Run settings ---"
  echo "datadir=$DATADIR size_mb=$SIZE_MB rate=$RATE duration=$DURATION seed=$SEED depth=$DEPTH direct=$DIRECT cpus=${CPUS:-none}"
  echo "--- Load at start ---"; uptime
  echo "--- CPU ---"; lscpu | head -20
  echo "--- Disk under DATADIR ---"; df -hT "$DATADIR"
} >> run_metadata.txt
mv run_metadata.txt "$OUT/"

# 2. test file (reuse if it already has the right size)
FILE=$DATADIR/testfile.bin
BYTES=$((SIZE_MB * 1024 * 1024))
if [ ! -f "$FILE" ] || [ "$(stat -c %s "$FILE")" != "$BYTES" ]; then
    ./mkfile "$FILE" "$SIZE_MB"
fi

# 3. trace (file-size must match the test file)
./trace_gen --mode steady --rate "$RATE" --duration "$DURATION" --seed "$SEED" \
            --file-size "$BYTES" --out "$OUT/trace_steady.csv"

# 4. the benchmark, pinned to the chosen CPU if CPUS is set
PIN=""
[ -n "$CPUS" ] && PIN="taskset -c $CPUS"
$PIN ./run_bench --file "$FILE" --trace "$OUT/trace_steady.csv" --policy wait \
     --depth "$DEPTH" --direct "$DIRECT" --out "$OUT/run_wait.csv" | tee "$OUT/summary_wait.txt"

echo "Done. Results in $OUT"
