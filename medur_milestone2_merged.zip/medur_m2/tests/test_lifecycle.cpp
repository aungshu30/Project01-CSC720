// test_lifecycle.cpp - lifecycle tests (plan task 2.3, owner: Medur)
//
// Covers:
//   A. policy 2 (continuous checking) basics                     (task 2.1)
//   B. empty queue                                               (2.3)
//   C. exhausted spin budget                                     (2.3)
//   D. zero budget still making progress                         (2.3)
//   E. shutdown with requests in flight                          (2.3)
//   F. Study B trace + over-time recorder                        (2.2)
//
// Slow completions are made with io_uring TIMEOUT operations: a timeout SQE completes after
// an exact delay, so we can test "the completion comes later than the spin budget" without
// depending on how fast the SSD is.
//
// Budgeted policy (policy 3): the tests use the team's entry point pick_policy("spin", us) from
// src/policies.h, so they test whatever policy 3 is currently plugged in there (Pasha's stand-in
// today, Sirisha's version once it replaces it). No change is needed here when that happens.
//
// Run:  ./test_lifecycle            (TESTDIR=/local/ssd/dir DIRECT=1 for the harness tests)
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "harness.h"
#include "policies.h"
#include "timeline.h"
#include "workload.h"

// Budgeted policy (policy 3) with a budget in ns, taken from the team's pick_policy().
static const Policy* g_budgeted = nullptr;
static int64_t g_test_budget = 0;
static int budgeted_policy(struct io_uring* r, struct io_uring_cqe** c, int64_t t) {
    g_budgeted = pick_policy("spin", g_test_budget / 1000.0);  // sets the spin time
    return g_budgeted->wait(r, c, t);
}
static const Policy kBudgeted = {"budgeted", budgeted_policy};
#define BUDGETED_NAME "policy 3 from pick_policy(\"spin\") in src/policies.h"

// ---------------------------------------------------------------- tiny test framework
static int failures = 0;
#define CHECK(cond, ...)                                     \
    do {                                                     \
        if (cond) { std::printf("ok:   "); }                 \
        else { std::printf("FAIL: "); failures++; }          \
        std::printf(__VA_ARGS__);                            \
        std::printf("\n");                                   \
    } while (0)

static uint64_t thread_cpu_ns() {
    timespec ts;
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    return uint64_t(ts.tv_sec) * 1000000000ull + uint64_t(ts.tv_nsec);
}
static double ms(uint64_t ns) { return ns / 1e6; }

// Submit one TIMEOUT op that completes after delay_ms (stands in for a slow read).
static __kernel_timespec g_ts[64];
static int g_ts_used = 0;
static void submit_delay(struct io_uring* ring, unsigned delay_ms, uint64_t tag) {
    __kernel_timespec* ts = &g_ts[g_ts_used++ % 64];
    ts->tv_sec = delay_ms / 1000;
    ts->tv_nsec = (delay_ms % 1000) * 1000000ll;
    struct io_uring_sqe* sqe = io_uring_get_sqe(ring);
    io_uring_prep_timeout(sqe, ts, 0, 0);
    io_uring_sqe_set_data64(sqe, tag);
    io_uring_submit(ring);
}

struct Measure { int rc; uint64_t wall, cpu; uint64_t tag; };
static Measure call(const Policy& p, struct io_uring* ring, int64_t timeout_ns) {
    struct io_uring_cqe* cqe = nullptr;
    uint64_t w0 = now_ns(), c0 = thread_cpu_ns();
    int rc = p.wait(ring, &cqe, timeout_ns);
    Measure m{rc, now_ns() - w0, thread_cpu_ns() - c0, 0};
    if (rc == 0 && cqe) { m.tag = io_uring_cqe_get_data64(cqe); io_uring_cqe_seen(ring, cqe); }
    return m;
}

// ---------------------------------------------------------------- test file for harness runs
static std::string g_dir;
static bool g_direct = true;
static std::string make_file(const std::string& name, size_t mib) {
    std::string path = g_dir + "/" + name;
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) { std::perror(path.c_str()); std::exit(2); }
    std::vector<unsigned char> buf(1 << 20);
    for (size_t m = 0; m < mib; m++) {
        pat::fill(buf.data(), m << 20, buf.size());
        std::fwrite(buf.data(), 1, buf.size(), f);
    }
    std::fclose(f);
    return path;
}

int main() {
    g_dir = std::getenv("TESTDIR") ? std::getenv("TESTDIR") : "./tmp_lifecycle";
    g_direct = !(std::getenv("DIRECT") && std::string(std::getenv("DIRECT")) == "0");
    mkdir(g_dir.c_str(), 0755);
    std::printf("budgeted policy under test: %s\n", BUDGETED_NAME);

    struct io_uring ring;
    if (io_uring_queue_init(64, &ring, 0) < 0) { std::printf("io_uring not available\n"); return 2; }

    // ===================================================== A. policy 2 (continuous checking)
    std::printf("-- A. policy 2: continuous checking\n");
    {
        // completion after 30 ms, no deadline: policy 2 must spin the whole time
        submit_delay(&ring, 30, 7);
        g_inflight = 1;
        Measure m = call(kPolicyContinuousCheck, &ring, -1);
        g_inflight = 0;
        CHECK(m.rc == 0 && m.tag == 7, "policy 2 returns the completion (rc=%d)", m.rc);
        CHECK(m.cpu > m.wall / 2, "policy 2 burns CPU while checking (cpu %.1f ms of %.1f ms wall)", ms(m.cpu), ms(m.wall));
        CHECK(g_budget_ns == -1, "policy 2 reports an unlimited budget (-1) to the recorder");
    }
    {
        // completion far away, but the next request is due in 10 ms: return -ETIME on time
        submit_delay(&ring, 200, 8);
        g_inflight = 1;
        Measure m = call(kPolicyContinuousCheck, &ring, 10000000);
        CHECK(m.rc == -ETIME, "policy 2 gives up at the next arrival time (rc=%d)", m.rc);
        CHECK(m.wall >= 9000000 && m.wall < 60000000, "  ...after about 10 ms (%.1f ms)", ms(m.wall));
        Measure m2 = call(kPolicyContinuousCheck, &ring, -1);  // collect it so the ring is empty
        g_inflight = 0;
        CHECK(m2.rc == 0 && m2.tag == 8, "policy 2 later collects that completion");
    }

    // ===================================================== B. empty queue
    std::printf("-- B. empty queue\n");
    {
        g_inflight = 0;
        Measure m = call(kPolicyContinuousCheck, &ring, 20000000);
        CHECK(m.rc == -ETIME, "policy 2, nothing outstanding: timed wait returns -ETIME (rc=%d)", m.rc);
        CHECK(m.wall >= 15000000, "  ...waits until the next arrival (%.1f ms)", ms(m.wall));
        CHECK(m.cpu < m.wall / 4, "  ...without spinning (cpu %.2f ms)", ms(m.cpu));

        m = call(kPolicyContinuousCheck, &ring, -1);
        CHECK(m.rc == -EAGAIN && m.wall < 5000000, "policy 2, nothing outstanding, no deadline: returns at once (-EAGAIN)");

        g_test_budget = 5000000;
        m = call(kBudgeted, &ring, 10000000);
        CHECK(m.rc == -ETIME, "budgeted policy, empty queue: returns -ETIME at the deadline (rc=%d)", m.rc);

        m = call(kPolicyWaitImmediately, &ring, 10000000);
        CHECK(m.rc == -ETIME, "policy 1, empty queue: returns -ETIME at the deadline (rc=%d)", m.rc);

        HarnessOptions opt;
        opt.file = "/does/not/matter";  // never opened for an empty trace
        RunResult r = run_harness(opt, {}, kPolicyContinuousCheck);
        CHECK(r.records.empty() && r.waits == 0 && g_inflight == 0, "harness with an empty trace returns at once");
    }

    // ===================================================== C. exhausted spin budget
    std::printf("-- C. exhausted spin budget\n");
    {
        g_test_budget = 2000000;  // 2 ms of checking
        submit_delay(&ring, 40, 9);  // completion only after 40 ms
        g_inflight = 1;
        Measure m = call(kBudgeted, &ring, -1);
        g_inflight = 0;
        CHECK(m.rc == 0 && m.tag == 9, "budget runs out, policy falls back to waiting and still gets the completion");
        CHECK(m.wall >= 35000000, "  ...completion arrived after the budget (%.1f ms)", ms(m.wall));
        CHECK(m.cpu < 15000000, "  ...CPU stays near the 2 ms budget, not 40 ms (cpu %.2f ms)", ms(m.cpu));

        g_test_budget = 50000000;  // budget much longer than the I/O: should be a spin "hit"
        submit_delay(&ring, 1, 10);
        g_inflight = 1;
        m = call(kBudgeted, &ring, -1);
        g_inflight = 0;
        CHECK(m.rc == 0 && m.tag == 10 && m.wall < 20000000, "budget not exhausted: completion found while checking (%.2f ms)", ms(m.wall));
    }

    // ===================================================== D. zero budget still makes progress
    std::printf("-- D. zero budget\n");
    {
        g_test_budget = 0;
        submit_delay(&ring, 20, 11);
        g_inflight = 1;
        Measure m = call(kBudgeted, &ring, -1);
        g_inflight = 0;
        CHECK(m.rc == 0 && m.tag == 11, "zero budget: completion still delivered (rc=%d)", m.rc);
        CHECK(m.cpu < 5000000, "  ...with no checking CPU (cpu %.2f ms)", ms(m.cpu));
    }

    // ===================================================== E. shutdown with requests in flight
    std::printf("-- E. shutdown with requests in flight\n");
    {
        // 8 slow operations in flight, then shut down: all must be drained first.
        for (int i = 0; i < 8; i++) submit_delay(&ring, 10 + 5 * i, 100 + i);
        size_t inflight = 8;
        std::vector<int> seen(8, 0);
        uint64_t got = harness_drain(&ring, inflight, [&](struct io_uring_cqe* c) {
            uint64_t t = io_uring_cqe_get_data64(c);
            if (t >= 100 && t < 108) seen[t - 100]++;
            io_uring_cqe_seen(&ring, c);
            inflight--;
        });
        bool once = true;
        for (int s : seen) once = once && s == 1;
        CHECK(got == 8 && inflight == 0, "drain collected all 8 in-flight completions before exit");
        CHECK(once, "  ...each exactly once");
        struct io_uring_cqe* c = nullptr;
        CHECK(io_uring_peek_cqe(&ring, &c) == -EAGAIN, "  ...and the completion queue is empty afterwards");
    }
    io_uring_queue_exit(&ring);

    // Harness-level runs on a real file
    const std::string file = make_file("lifecycle.bin", 16);
    wl::Config wcfg;
    wcfg.seed = 5;
    wcfg.file_size = 16ull << 20;
    HarnessOptions opt;
    opt.file = file;
    opt.direct = g_direct;
    opt.depth = 8;

    {
        auto trace = wl::generate_steady(wcfg, 4000, 1.0);  // ~4000 reads over 1 s
        opt.stop_at_ns = 300000000;                          // stop after 0.3 s
        RunResult r = run_harness(opt, trace, kPolicyContinuousCheck);
        opt.stop_at_ns = 0;
        size_t submitted = 0, complete_ok = 0, half = 0;
        for (auto& x : r.records) {
            bool never = x.complete_ns == 0 && x.result == -ECANCELED;
            if (never) continue;
            submitted++;
            if (x.complete_ns >= x.submit_ns && x.result == int(x.size) && x.verify_ok) complete_ok++;
            else half++;
        }
        CHECK(r.stopped_early, "harness stop: run stopped early at 0.3 s");
        CHECK(r.not_submitted > 0 && submitted + r.not_submitted == trace.size(),
              "  ...%zu submitted + %llu never submitted = %zu requests", submitted,
              (unsigned long long)r.not_submitted, trace.size());
        CHECK(half == 0 && complete_ok == submitted, "  ...every submitted read completed and verified (%llu drained at stop)",
              (unsigned long long)r.drained);
        CHECK(g_inflight == 0, "  ...nothing left in flight after the harness returns");

        g_stop_requested = 1;  // like Ctrl-C before the first request
        r = run_harness(opt, trace, kPolicyWaitImmediately);
        g_stop_requested = 0;
        CHECK(r.stopped_early && r.not_submitted == trace.size(), "stop request (Ctrl-C) exits cleanly with nothing submitted");
    }
    {
        auto trace = wl::generate_steady(wcfg, 3000, 0.5);
        g_test_budget = 0;
        RunResult r = run_harness(opt, trace, kBudgeted);
        CHECK(r.records.size() == trace.size() && r.errors == 0 && r.verify_failures == 0,
              "zero budget in the harness: all %zu reads complete and verify", trace.size());
        r = run_harness(opt, trace, kPolicyContinuousCheck);
        CHECK(r.errors == 0 && r.verify_failures == 0 && r.short_reads == 0,
              "policy 2 in the harness: all %zu reads complete and verify", trace.size());
    }

    // ===================================================== F. Study B trace + recorder
    std::printf("-- F. Study B trace and over-time recorder\n");
    {
        auto ph = wl::studyb_phases(500, 8000, 0.3, 0.1, 0.2, 3);
        CHECK(ph.size() == 7, "studyb phases: sparse, 3 bursts with 2 gaps, sparse (%zu phases)", ph.size());
        wl::Config c1 = wcfg; c1.seed = 2002;
        auto a = wl::generate(c1, ph), b = wl::generate(c1, ph);
        bool same = a.size() == b.size();
        for (size_t i = 0; same && i < a.size(); i++) same = a[i].arrival_ns == b[i].arrival_ns && a[i].offset == b[i].offset;
        CHECK(same, "studyb trace: same seed gives identical arrival times");
        wl::Config c2 = wcfg; c2.seed = 1001;  // e.g. a calibration seed
        auto d = wl::generate(c2, ph);
        CHECK(!(d.size() == a.size() && d[0].arrival_ns == a[0].arrival_ns), "studyb trace differs from a trace with another seed");

        size_t in_burst = 0;
        for (auto& r : a) { double t = r.arrival_ns / 1e9; if (t >= 0.3 && t < 0.4) in_burst++; }
        size_t in_sparse = 0;
        for (auto& r : a) { double t = r.arrival_ns / 1e9; if (t < 0.1) in_sparse++; }
        CHECK(in_burst > 5 * in_sparse, "burst is much denser than sparse (%zu vs %zu per 100 ms)", in_burst, in_sparse);

        bool threw = false;
        try { wl::studyb_phases(5000, 1000, 1, 1, 1, 2); } catch (const std::invalid_argument&) { threw = true; }
        CHECK(threw, "studyb rejects burst_rate <= sparse_rate");

        TimelineRecorder tl(10000000);  // 10 ms windows
        opt.timeline = &tl;
        g_budget_ns = -1;
        RunResult r = run_harness(opt, a, kPolicyContinuousCheck);
        opt.timeline = nullptr;
        const auto& W = tl.windows();
        uint64_t comp = 0, cpu = 0, arr = 0;
        bool budget_ok = true;
        for (auto& w : W) { comp += w.completions; cpu += w.cpu_ns; arr += w.arrivals; budget_ok = budget_ok && w.budget_ns == -1; }
        size_t expect_w = size_t((r.wall_ns + tl.window_ns() - 1) / tl.window_ns());
        CHECK(W.size() == expect_w, "recorder: %zu windows for a %.3f s run", W.size(), r.wall_ns / 1e9);
        CHECK(comp == a.size() && arr == a.size(), "recorder: every arrival and completion lands in one window");
        CHECK(cpu == r.cpu_ns, "recorder: window CPU adds up to the run CPU (%.2f ms)", ms(cpu));
        CHECK(budget_ok, "recorder: budget column shows the policy's budget");
        CHECK(W.back().pending_end == 0 && W.back().inflight_end == 0, "recorder: nothing pending at the end");
        tl.write_csv(g_dir + "/timeline_test.csv", "continuous_check");
        FILE* f = std::fopen((g_dir + "/timeline_test.csv").c_str(), "r");
        CHECK(f != nullptr, "recorder: CSV written");
        if (f) std::fclose(f);
    }

    std::remove(file.c_str());
    std::remove((g_dir + "/timeline_test.csv").c_str());
    rmdir(g_dir.c_str());
    if (failures == 0) std::printf("LIFECYCLE TESTS PASSED\n");
    else std::printf("LIFECYCLE TESTS FAILED (%d)\n", failures);
    return failures ? 1 : 0;
}
