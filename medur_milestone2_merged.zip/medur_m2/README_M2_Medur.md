# Milestone 2: Medur's part (tasks 2.1, 2.2, 2.3)

Built on the team's Milestone 2 code (Pasha's `src/` layout from project_results_and_code.tar.gz).
Pasha's capacity, calibrate and pilot tools and his tests are unchanged and still pass.

## New files
    src/harness_state.h        2.1  g_budget_ns (budget for the recorder), g_stop_requested (clean stop)
    src/timeline.h             2.2  over-time recorder: budget, CPU, latency, pending per time window
    make_studyb_trace.sh       2.2  builds the fixed Study B trace from loads.conf (sparse, 3 bursts, sparse)
    tests/test_lifecycle.cpp   2.3  lifecycle tests (39 checks)
    run_milestone2_medur.sh         runs policies 1, 2, 3 on the Study B trace + clean-stop test

## Changed files (changes marked "M2")
    src/policy_poll.h   REPLACED Pasha's stand-in with the real policy 2 (same names: kPolicyPoll, "poll")
    src/harness.h       keeps g_inflight current, calls the recorder, clean shutdown (drains in-flight reads)
    src/workload.h      studyb_phases(), generate_studyb(), write_phases_csv()
    src/trace_gen.cpp   new --mode studyb
    src/run_bench.cpp   --timeline FILE, --window_ms N, --stop_after_s S, Ctrl-C = clean stop, "check" = "poll"
    src/summary.h       skips reads that were never submitted (only matters after an early stop)
    Makefile            builds test_lifecycle; make test runs it

## Build and test
    make                                  # or: make LIBURING=$HOME/liburing-inst
    TESTDIR=$HOME/ssd_test/selftest make test
Expect: ALL TESTS PASSED, HARNESS TESTS PASSED, MILESTONE 2 TESTS PASSED, LIFECYCLE TESTS PASSED.
Do NOT run `make clean`: it deletes loads.conf and calibration.conf (Pasha's results).

## Study B trace
    sh make_studyb_trace.sh
Reads light_rps (sparse) and moderate_rps (bursts) from loads.conf. Output in traces/:
studyb_trace.csv, studyb_phases.csv, studyb_trace.info (seed + sha256).
Seed 2002 is reserved for Study B (calibration uses 9001, the Study A pilot uses 1).

## Run one policy with the recorder
    ./run_bench --file $HOME/ssd_test/testfile.bin --trace traces/studyb_trace.csv \
                --policy poll --out b_poll.csv --timeline b_poll_timeline.csv --window_ms 10

Timeline CSV columns: policy, window, start_s, end_s, budget_ns, cpu_ns, cpu_util, cpu_samples,
arrivals, submits, completions, lat_p50_us, lat_p99_us, resp_p50_us, resp_p99_us, pending_end, inflight_end.
budget_ns: 0 = no spinning, -1 = unlimited (policy 2), >0 = spin budget in ns (policy 3, later policy 4).

## For teammates
- Pasha: src/policy_poll.h is now the real policy 2. Same names, so pilot and calibrate need no change.
- Sirisha: when your policy 3 replaces src/policy_spin.h, keep it reachable through
  pick_policy("spin", spin_us) in src/policies.h. test_lifecycle tests policy 3 through that call, so
  your version is tested automatically. To have the timeline show your budget, set g_budget_ns = spin_ns.
