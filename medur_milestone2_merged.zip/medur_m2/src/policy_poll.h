// policy_poll.h - policy 2: continuous checking (plan task 2.1, owner: Medur)
// Replaces Pasha's stand-in. Same names (kPolicyPoll, policy name "poll"), so pick_policy(),
// pilot and calibrate keep working unchanged.
//
// While at least one read is outstanding, the thread loops on io_uring_peek_cqe and never
// sleeps. This shows the full CPU cost of polling: every failed check is burned CPU time.
//
// When NO read is outstanding there is nothing to check for, so the policy does not spin.
// It does a timed sleep (io_uring_wait_cqe_timeout) until the next request is due.
//
// Return values follow the Policy contract in common.h:
//   0        a completion is in *cqe
//   -ETIME   the deadline (next arrival) was reached, *cqe == nullptr
//   -EAGAIN  nothing outstanding and no next arrival (the harness just loops again)
#pragma once
#include <cerrno>

#include "common.h"
#include "harness_state.h"

inline int policy_continuous_check(struct io_uring* ring, struct io_uring_cqe** cqe, int64_t timeout_ns) {
    *cqe = nullptr;
    g_budget_ns = -1;  // unlimited checking, for the over-time recorder

    // Case 1: nothing outstanding -> timed wait for the next arrival (no spinning).
    if (g_inflight == 0) {
        if (timeout_ns < 0) return -EAGAIN;
        struct __kernel_timespec ts;
        ts.tv_sec = timeout_ns / 1000000000;
        ts.tv_nsec = timeout_ns % 1000000000;
        return io_uring_wait_cqe_timeout(ring, cqe, &ts);
    }

    // Case 2: reads outstanding -> check the completion queue in a tight loop.
    // Stop early only if the next request is due, so the harness can submit it.
    const bool has_deadline = timeout_ns >= 0;
    const uint64_t deadline = has_deadline ? now_ns() + static_cast<uint64_t>(timeout_ns) : 0;
    for (;;) {
        int r = io_uring_peek_cqe(ring, cqe);
        if (r == 0 && *cqe) return 0;
        if (r != -EAGAIN) return r;  // a real error
        *cqe = nullptr;
        if (has_deadline && now_ns() >= deadline) return -ETIME;
    }
}

inline const Policy kPolicyPoll = {"poll", policy_continuous_check};
inline const Policy& kPolicyContinuousCheck = kPolicyPoll;  // older name, used in the tests
