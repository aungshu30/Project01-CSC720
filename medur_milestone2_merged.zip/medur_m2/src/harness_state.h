// harness_state.h - small shared state for Milestone 2 (Medur, tasks 2.1 to 2.3)
//
// g_inflight (reads outstanding) already lives in common.h. This file adds two more values
// without changing the agreed Policy signature. Single-threaded benchmark, so plain globals are fine.
#pragma once
#include <csignal>
#include <cstdint>

#include "common.h"

// Spin budget currently in use, in ns, saved by the over-time recorder (Study B).
//   0  = no spinning (policy 1, or a zero budget)
//  -1  = unlimited (policy 2, continuous checking)
//  >0  = fixed or adaptive budget (policies 3 and 4 set this when they change it)
inline int64_t g_budget_ns = 0;

// Set to 1 (from the SIGINT handler in run_bench) to ask the harness to stop submitting new
// reads, drain the reads already in flight, and exit cleanly.
inline volatile std::sig_atomic_t g_stop_requested = 0;
