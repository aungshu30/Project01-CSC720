// timeline.h - over-time recorder for Study B (plan task 2.2, owner: Medur)
//
// Splits a run into fixed time windows (default 10 ms) and saves, per window:
//   budget, CPU use, latency (p50 / p99) and pending requests.
//
// To keep the measurement cheap, only two things are sampled DURING the run:
//   - process CPU time   (cannot be rebuilt afterwards)
//   - the spin budget    (g_budget_ns, set by the policy)
// Everything else (latency, arrivals, completions, pending, in flight) is computed AFTER the
// run from the per-request records, so it adds no work inside the timed loop.
//
// Note: the harness only "ticks" the recorder between policy calls. If the thread sleeps
// across several windows (policy 1 during a sparse phase), the skipped windows get 0 CPU and
// the window where it wakes up gets the whole CPU delta. CPU used while asleep is ~0, so the
// error is small; the column cpu_samples shows how many samples a window got (0 = skipped).
#pragma once
#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <ctime>
#include <stdexcept>
#include <string>
#include <vector>

#include "common.h"
#include "harness_state.h"

struct TimelineWindow {
    uint64_t start_ns = 0;
    uint64_t cpu_ns = 0;        // process CPU used in this window (live sample)
    uint32_t cpu_samples = 0;   // live samples that closed in this window
    int64_t budget_ns = 0;      // spin budget at the end of this window (live sample)
    // filled in by finalize():
    uint64_t arrivals = 0, submits = 0, completions = 0;
    double lat_p50_us = 0, lat_p99_us = 0;    // submit -> complete, for reads completed here
    double resp_p50_us = 0, resp_p99_us = 0;  // arrival -> complete
    uint64_t pending_end = 0;   // arrived but not completed at window end
    uint64_t inflight_end = 0;  // submitted but not completed at window end
};

class TimelineRecorder {
public:
    explicit TimelineRecorder(uint64_t window_ns = 10000000ull) : win_(window_ns) {
        if (win_ == 0) throw std::invalid_argument("timeline window must be > 0");
    }

    // Called by the harness right after the clock starts.
    void start(uint64_t cpu0) {
        windows_.clear();
        next_ = win_;
        last_cpu_ = cpu0;
        windows_.reserve(4096);
    }

    // Called once per harness loop iteration with the run-relative time. Cheap when no
    // window boundary was crossed (one comparison).
    inline void tick(uint64_t now_rel) {
        if (now_rel < next_) return;
        close_until(now_rel);
    }

    // Called once at the end of the timed run. Closes the last (partial) window and then
    // computes the per-window latency / pending columns from the records.
    template <class Rec>
    void finalize(uint64_t wall_ns, uint64_t cpu_end, const std::vector<Rec>& recs) {
        close_until(wall_ns, cpu_end, /*final=*/true);
        fill_from_records(recs);
    }

    void write_csv(const std::string& path, const char* policy) const {
        FILE* f = std::fopen(path.c_str(), "w");
        if (!f) throw std::runtime_error("cannot open timeline output " + path);
        std::fprintf(f,
                     "policy,window,start_s,end_s,budget_ns,cpu_ns,cpu_util,cpu_samples,arrivals,submits,"
                     "completions,lat_p50_us,lat_p99_us,resp_p50_us,resp_p99_us,pending_end,inflight_end\n");
        for (size_t i = 0; i < windows_.size(); i++) {
            const TimelineWindow& w = windows_[i];
            std::fprintf(f, "%s,%zu,%.6f,%.6f,%lld,%llu,%.4f,%u,%llu,%llu,%llu,%.2f,%.2f,%.2f,%.2f,%llu,%llu\n",
                         policy, i, w.start_ns / 1e9, (w.start_ns + win_) / 1e9, (long long)w.budget_ns,
                         (unsigned long long)w.cpu_ns, double(w.cpu_ns) / double(win_), w.cpu_samples,
                         (unsigned long long)w.arrivals, (unsigned long long)w.submits,
                         (unsigned long long)w.completions, w.lat_p50_us, w.lat_p99_us, w.resp_p50_us,
                         w.resp_p99_us, (unsigned long long)w.pending_end, (unsigned long long)w.inflight_end);
        }
        std::fclose(f);
    }

    const std::vector<TimelineWindow>& windows() const { return windows_; }
    uint64_t window_ns() const { return win_; }

private:
    static uint64_t proc_cpu() {
        timespec ts;
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
        return uint64_t(ts.tv_sec) * 1000000000ull + uint64_t(ts.tv_nsec);
    }

    void close_until(uint64_t now_rel, uint64_t cpu_now = 0, bool final = false) {
        if (!final) cpu_now = proc_cpu();
        // Open every window up to the one containing now_rel (skipped ones stay at 0 CPU).
        const size_t need = final ? size_t((now_rel + win_ - 1) / win_) : size_t(now_rel / win_);
        while (windows_.size() < std::max<size_t>(need, 1)) {
            TimelineWindow w;
            w.start_ns = uint64_t(windows_.size()) * win_;
            w.budget_ns = g_budget_ns;
            windows_.push_back(w);
        }
        // The CPU since the last sample goes to the last window that has fully ended
        // (or, at the end of the run, to the final partial window).
        TimelineWindow& w = windows_.back();
        w.cpu_ns += cpu_now - last_cpu_;
        w.cpu_samples++;
        w.budget_ns = g_budget_ns;
        last_cpu_ = cpu_now;
        next_ = (now_rel / win_ + 1) * win_;
    }

    static double pct_us(std::vector<uint64_t>& v, double p) {
        if (v.empty()) return 0;
        std::sort(v.begin(), v.end());
        size_t i = size_t(p * double(v.size() - 1) + 0.5);
        return double(v[i]) / 1e3;
    }

    template <class Rec>
    void fill_from_records(const std::vector<Rec>& recs) {
        const size_t W = windows_.size();
        if (W == 0) return;
        auto widx = [&](uint64_t t) { return std::min<size_t>(size_t(t / win_), W - 1); };
        std::vector<std::vector<uint64_t>> lat(W), resp(W);
        std::vector<uint64_t> arr, sub, comp;  // times, for pending / in-flight counts
        for (const Rec& r : recs) {
            arr.push_back(r.arrival_ns);
            windows_[widx(r.arrival_ns)].arrivals++;
            const bool submitted = !(r.complete_ns == 0 && r.result == -ECANCELED);
            if (!submitted) continue;  // never submitted (run was stopped early)
            sub.push_back(r.submit_ns);
            comp.push_back(r.complete_ns);
            windows_[widx(r.submit_ns)].submits++;
            const size_t c = widx(r.complete_ns);
            windows_[c].completions++;
            lat[c].push_back(r.complete_ns - r.submit_ns);
            resp[c].push_back(r.complete_ns - r.arrival_ns);
        }
        std::sort(arr.begin(), arr.end());
        std::sort(sub.begin(), sub.end());
        std::sort(comp.begin(), comp.end());
        size_t ia = 0, is = 0, ic = 0;
        for (size_t i = 0; i < W; i++) {
            TimelineWindow& w = windows_[i];
            w.lat_p50_us = pct_us(lat[i], 0.50);
            w.lat_p99_us = pct_us(lat[i], 0.99);
            w.resp_p50_us = pct_us(resp[i], 0.50);
            w.resp_p99_us = pct_us(resp[i], 0.99);
            const uint64_t end = w.start_ns + win_;
            while (ia < arr.size() && arr[ia] < end) ia++;
            while (is < sub.size() && sub[is] < end) is++;
            while (ic < comp.size() && comp[ic] < end) ic++;
            // requests that were never submitted still count as pending once they arrive
            w.pending_end = ia > ic ? ia - ic : 0;
            w.inflight_end = is > ic ? is - ic : 0;
        }
    }

    uint64_t win_;
    uint64_t next_ = 0;
    uint64_t last_cpu_ = 0;
    std::vector<TimelineWindow> windows_;
};
