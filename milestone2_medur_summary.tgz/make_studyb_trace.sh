#!/bin/sh
# make_studyb_trace.sh - build the fixed Study B trace (plan task 2.2, owner: Medur)
#
# Sparse -> 3 bursts -> sparse, with fixed arrival times (fixed seed). It is made ONCE, saved, and
# then replayed unchanged by every policy in Studies B and C.
#
# The rates come from Pasha's capacity test (loads.conf, written by ./capacity):
#   sparse phases = light_rps     (10% of measured capacity)
#   bursts        = moderate_rps  (50% of measured capacity)
#
#   sh make_studyb_trace.sh                       # reads loads.conf, file size from the test file
#   FILE=$HOME/ssd_test/testfile.bin sh make_studyb_trace.sh
#   SPARSE_RATE=13300 BURST_RATE=66900 FILE_SIZE=1073741824 sh make_studyb_trace.sh   # set by hand
set -e
OUT=${OUT:-traces}
LOADS=${LOADS:-loads.conf}
CALIB=${CALIB:-calibration.conf}
SEED=${SEED:-2002}               # reserved for Study B. Calibration uses 9001, Study A pilot uses 1.
SPARSE_SECS=${SPARSE_SECS:-5}
BURST_SECS=${BURST_SECS:-1}
GAP_SECS=${GAP_SECS:-2}
BURSTS=${BURSTS:-3}

conf() { awk -F= -v k="$2" '$1==k {print $2}' "$1"; }
if [ -z "$SPARSE_RATE" ] || [ -z "$BURST_RATE" ]; then
    [ -f "$LOADS" ] || { echo "ERROR: $LOADS not found. Copy Pasha's loads.conf here, or set SPARSE_RATE and BURST_RATE."; exit 1; }
    SPARSE_RATE=${SPARSE_RATE:-$(conf "$LOADS" light_rps)}
    BURST_RATE=${BURST_RATE:-$(conf "$LOADS" moderate_rps)}
fi
if [ -z "$FILE_SIZE" ]; then
    if [ -n "$FILE" ] && [ -f "$FILE" ]; then FILE_SIZE=$(stat -c %s "$FILE"); else FILE_SIZE=1073741824; fi
fi

# Keep Study B separate from the calibration trace (calibrate writes its seed in the header line).
if [ -f "$CALIB" ] && grep -q "seed $SEED[,)]" "$CALIB"; then
    echo "ERROR: $CALIB was made with seed $SEED, the Study B seed. Use another SEED."; exit 1
fi

mkdir -p "$OUT"
./trace_gen --mode studyb --seed "$SEED" --file-size "$FILE_SIZE" \
    --sparse-rate "$SPARSE_RATE" --burst-rate "$BURST_RATE" \
    --sparse-secs "$SPARSE_SECS" --burst-secs "$BURST_SECS" --gap-secs "$GAP_SECS" --bursts "$BURSTS" \
    --out "$OUT/studyb_trace.csv" --phases-out "$OUT/studyb_phases.csv"

# Save how the trace was made, plus a checksum so we can show it never changed between runs.
{
    echo "seed=$SEED"; echo "sparse_rate=$SPARSE_RATE"; echo "burst_rate=$BURST_RATE"
    echo "sparse_secs=$SPARSE_SECS"; echo "burst_secs=$BURST_SECS"; echo "gap_secs=$GAP_SECS"
    echo "bursts=$BURSTS"; echo "file_size=$FILE_SIZE"
    [ -f "$LOADS" ] && echo "capacity_rps=$(conf "$LOADS" capacity_rps)"
    [ -f "$CALIB" ] && echo "calibration_seed=$(sed -n 's/.*seed \([0-9]*\).*/\1/p' "$CALIB" | head -1)"
    echo "sha256=$(sha256sum "$OUT/studyb_trace.csv" | cut -d' ' -f1)"
} > "$OUT/studyb_trace.info"
cat "$OUT/studyb_trace.info"
echo "ok: Study B trace uses seed $SEED, separate from the calibration trace"
