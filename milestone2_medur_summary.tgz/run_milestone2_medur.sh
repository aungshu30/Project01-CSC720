#!/bin/bash
# run_milestone2_medur.sh - Milestone 2, Medur's part (tasks 2.1, 2.2, 2.3).
# Replays the fixed Study B trace with policy 1 (wait), policy 2 (poll) and policy 3 (spin at the
# three calibrated durations from calibration.conf), saves per-request CSVs and the over-time
# timeline CSVs, then does a clean-stop test with reads in flight.
# Usage: DATADIR=$HOME/ssd_test CPUS=4 ./run_milestone2_medur.sh
# Optional: TRACE (traces/studyb_trace.csv), CALIB (calibration.conf), DEPTH (32), DIRECT (1),
#           WINDOW_MS (10), SIZE_MB (1024)
set -e

DATADIR=${DATADIR:?set DATADIR to a folder on the local SSD}
TRACE=${TRACE:-traces/studyb_trace.csv}
CALIB=${CALIB:-calibration.conf}
DEPTH=${DEPTH:-32}
DIRECT=${DIRECT:-1}
WINDOW_MS=${WINDOW_MS:-10}
SIZE_MB=${SIZE_MB:-1024}
CPUS=${CPUS:-}

[ -f "$TRACE" ] || { echo "missing $TRACE: run make_studyb_trace.sh first"; exit 1; }
conf() { awk -F= -v k="$2" '$1==k {print $2}' "$1"; }
SPINS=""
if [ -f "$CALIB" ]; then
    SPINS="$(conf "$CALIB" spin_short_us) $(conf "$CALIB" spin_mid_us) $(conf "$CALIB" spin_long_us)"
else
    echo "note: $CALIB not found, policy 3 is skipped"
fi

STAMP=$(date +%Y%m%d_%H%M%S)
OUT=results/m2_studyb_$STAMP
mkdir -p "$OUT" "$DATADIR"
echo "Host: $(hostname)    Output: $OUT"

# 1. environment record
if [ -f record_env.sh ]; then bash record_env.sh >/dev/null 2>&1 && mv run_metadata.txt "$OUT/" || true; fi
{ echo; echo "--- Run settings ---"
  echo "trace=$TRACE depth=$DEPTH direct=$DIRECT window_ms=$WINDOW_MS cpus=${CPUS:-none} spins_us=${SPINS:-none}"
  echo "--- Trace info ---"; cat "${TRACE%_trace.csv}_trace.info" 2>/dev/null || true
  echo "trace_sha256_now=$(sha256sum "$TRACE" | cut -d' ' -f1)"
  echo "--- Load at start ---"; uptime
  echo "--- Kernel / CPU ---"; uname -r; lscpu | head -20
  echo "--- Disk under DATADIR ---"; df -hT "$DATADIR"
} >> "$OUT/run_metadata.txt"
cp "${TRACE%_trace.csv}_phases.csv" "$OUT/" 2>/dev/null || true

# 2. test file (reuse if it already has the right size)
FILE=$DATADIR/testfile.bin
BYTES=$((SIZE_MB * 1024 * 1024))
if [ ! -f "$FILE" ] || [ "$(stat -c %s "$FILE")" != "$BYTES" ]; then
    ./mkfile "$FILE" "$SIZE_MB"
fi

PIN=""
[ -n "$CPUS" ] && PIN="taskset -c $CPUS"

run() {  # run <label> <run_bench args...>
    local L=$1; shift
    echo "=== $L ==="
    $PIN ./run_bench --file "$FILE" --trace "$TRACE" --depth "$DEPTH" --direct "$DIRECT" \
         --out "$OUT/run_$L.csv" --timeline "$OUT/timeline_$L.csv" --window_ms "$WINDOW_MS" "$@" \
         | tee "$OUT/summary_$L.txt"
}

# 3. every policy on the identical Study B trace, with the over-time recorder
run wait --policy wait
run poll --policy poll
for S in $SPINS; do run "spin${S}" --policy spin --spin_us "$S"; done

# 4. clean shutdown with reads in flight (task 2.3): stop policy 2 in the middle of burst 1
echo "=== clean stop test (policy poll, stop at 5.5 s) ==="
$PIN ./run_bench --file "$FILE" --trace "$TRACE" --policy poll \
     --depth "$DEPTH" --direct "$DIRECT" --stop_after_s 5.5 \
     --out "$OUT/run_poll_stop.csv" | tee "$OUT/summary_poll_stop.txt"

echo "Done. Results in $OUT"
