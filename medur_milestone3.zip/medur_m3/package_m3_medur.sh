#!/bin/bash
# package_m3_medur.sh - pack Medur's Milestone 3 code and Study B results for GitHub (branch medur-milestone3).
#   ./package_m3_medur.sh [results/m3_studyb_<time>]      (default: the newest Study B results folder)
# Makes the folder upload_m3/ with:
#   medur_milestone3_code.zip        the source tree (no binaries, no big traces, no results)
#   milestone3_medur_summary.tgz     Study B tables, timelines, adaptive logs, configs, environment (small)
#   milestone3_medur_raw.tar.xz.partNN   per-request CSVs, split into 20 MB parts (only if raw/ exists)
# Every file is under 25 MB, so it can also be uploaded through the GitHub web page.
set -e
RES=${1:-$(ls -d results/m3_studyb_* 2>/dev/null | sort | tail -1)}
[ -n "$RES" ] && [ -d "$RES" ] || { echo "no results folder found (run ./run_studyb_m3.sh first)"; exit 2; }
UP=upload_m3
rm -rf "$UP"; mkdir -p "$UP"

# 1. code
zip -q -r "$UP/medur_milestone3_code.zip" Makefile *.sh *.md bench.conf.example src tests \
    traces/studyb_trace.info traces/studyb_phases.csv loads.conf calibration.conf 2>/dev/null || \
zip -q -r "$UP/medur_milestone3_code.zip" Makefile *.sh *.md src tests

# 2. small results
tar -czf "$UP/milestone3_medur_summary.tgz" --exclude="$(basename "$RES")/raw" -C "$(dirname "$RES")" "$(basename "$RES")"

# 3. raw per-request files, split for upload
if [ -d "$RES/raw" ] && [ -n "$(ls -A "$RES/raw")" ]; then
    echo "compressing raw per-request CSVs (takes a few minutes)..."
    tar -C "$RES" -cJf - raw | split -b 20M -d - "$UP/milestone3_medur_raw.tar.xz.part"
fi

( cd "$UP" && sha256sum * > SHA256SUMS.txt )
echo "Ready to upload:"; ls -lh "$UP"
echo
echo "To put the raw parts back together later:  cat milestone3_medur_raw.tar.xz.part* | tar -xJf -"
