// run_bench - run one policy over one trace and write per-request results.
//
//   ./run_bench --file /local/ssd/test.bin --trace steady.csv --policy wait --out run1.csv
//   ./run_bench --config bench.conf          (key=value lines; command line overrides the file)
//
// Config keys: file, trace, policy (wait|poll|spin|adaptive), spin_us (for spin), depth, direct (1/0), verify (1/0), out
// M3 keys (Medur, policy 4): acct_log=FILE (per-interval allowance CSV), allowance_clip=0/1, measure_spin_cpu=0/1,
//                  probe_backoff=N, probes_per_window=N, probe_level=1..3
// M2 keys (Medur): timeline=FILE (over-time CSV for Study B), window_ms=N (timeline window, default 10),
//                  stop_after_s=S (clean early stop). policy=check is accepted as another name for poll.
// Ctrl-C stops cleanly: no new reads are submitted, reads in flight are drained, results are still written.
#include <algorithm>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <sstream>

#include "adaptive_args.h"  // M3
#include "harness.h"
#include "policies.h"
#include "timeline.h"  // M2

static void on_sigint(int) { g_stop_requested = 1; }  // M2: Ctrl-C = clean shutdown

static std::vector<wl::Request> read_trace(const std::string& path) {
    std::ifstream f(path);
    if (!f) throw std::runtime_error("cannot open trace " + path);
    std::string line;
    std::getline(f, line);  // header: id,arrival_ns,offset,size
    std::vector<wl::Request> t;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        wl::Request r;
        unsigned long long id, a, o, s;
        if (std::sscanf(line.c_str(), "%llu,%llu,%llu,%llu", &id, &a, &o, &s) != 4)
            throw std::runtime_error("bad trace line: " + line);
        r.id = id; r.arrival_ns = a; r.offset = o; r.size = static_cast<uint32_t>(s);
        if (r.id != t.size()) throw std::runtime_error("trace ids must be 0,1,2,... in order");
        if (!t.empty() && r.arrival_ns < t.back().arrival_ns) throw std::runtime_error("trace arrivals go backwards");
        t.push_back(r);
    }
    return t;
}

static double pct(std::vector<uint64_t>& v, double p) {
    if (v.empty()) return 0;
    std::sort(v.begin(), v.end());
    size_t i = static_cast<size_t>(p * (v.size() - 1) + 0.5);
    return static_cast<double>(v[i]);
}

int main(int argc, char** argv) {
    std::map<std::string, std::string> cfg;
    // pass 1: find --config
    for (int i = 1; i + 1 < argc; i += 2)
        if (std::string(argv[i]) == "--config") {
            std::ifstream f(argv[i + 1]);
            if (!f) { std::cerr << "cannot open config " << argv[i + 1] << "\n"; return 2; }
            std::string line;
            while (std::getline(f, line)) {
                if (line.empty() || line[0] == '#') continue;
                auto eq = line.find('=');
                if (eq == std::string::npos) continue;
                cfg[line.substr(0, eq)] = line.substr(eq + 1);
            }
        }
    for (int i = 1; i + 1 < argc; i += 2) {
        std::string k = argv[i];
        if (k.rfind("--", 0) != 0) { std::cerr << "bad argument " << k << "\n"; return 2; }
        if (k != "--config") cfg[k.substr(2)] = argv[i + 1];
    }
    auto need = [&](const char* k) {
        if (!cfg.count(k)) { std::cerr << "missing --" << k << "\n"; std::exit(2); }
        return cfg[k];
    };

    try {
        HarnessOptions opt;
        opt.file = need("file");
        std::string tracef = need("trace");
        std::string policy = cfg.count("policy") ? cfg["policy"] : "wait";
        if (cfg.count("depth")) opt.depth = static_cast<unsigned>(std::atoi(cfg["depth"].c_str()));
        if (cfg.count("direct")) opt.direct = cfg["direct"] != "0";
        if (cfg.count("verify")) opt.verify = cfg["verify"] != "0";
        if (opt.depth == 0) throw std::runtime_error("depth must be at least 1");
        // M2: clean early stop and the over-time recorder
        if (cfg.count("stop_after_s")) opt.stop_at_ns = static_cast<uint64_t>(std::atof(cfg["stop_after_s"].c_str()) * 1e9);
        std::unique_ptr<TimelineRecorder> tl;
        if (cfg.count("timeline")) {
            double wms = cfg.count("window_ms") ? std::atof(cfg["window_ms"].c_str()) : 10.0;
            tl.reset(new TimelineRecorder(static_cast<uint64_t>(wms * 1e6)));
            opt.timeline = tl.get();
        }
        std::signal(SIGINT, on_sigint);
        if (policy == "check") policy = "poll";  // M2: same policy, older name

        const double spin_us = cfg.count("spin_us") ? std::atof(cfg["spin_us"].c_str()) : 0.0;
        // M3 (task 3.1): settings of policy 4. Budgets come from calibration.conf (--calib) or --short_us/--mid_us/--long_us.
        if (policy == "adaptive") {
            if (cfg.count("calib")) {
                std::ifstream cf(cfg["calib"]);
                if (!cf) throw std::runtime_error("cannot open calibration file " + cfg["calib"]);
                std::string line;
                while (std::getline(cf, line)) {
                    if (line.empty() || line[0] == '#') continue;
                    auto eq = line.find('=');
                    if (eq != std::string::npos) cfg.emplace(line.substr(0, eq), line.substr(eq + 1));  // command line wins
                }
            }
            g_adapt_cfg = adaptive_config_from([&](const char* k, double d) { return cfg.count(k) ? std::atof(cfg[k].c_str()) : d; });
            g_acct_cfg = acct_config_from([&](const char* k, double d) { return cfg.count(k) ? std::atof(cfg[k].c_str()) : d; });  // M3 Medur
        }
        const Policy* pol = pick_policy(policy, spin_us);
        if (!pol) throw std::runtime_error("unknown policy '" + policy + "' (use wait, poll, spin or adaptive)");
        // M2: budget column of the timeline (0 = no spinning, -1 = unlimited, >0 = spin budget in ns)
        if (policy != "adaptive")  // policy 4 keeps g_budget_ns up to date itself
            g_budget_ns = policy == "wait" ? 0 : policy == "poll" ? -1 : static_cast<int64_t>(spin_us * 1000.0);

        auto trace = read_trace(tracef);
        RunResult r = run_harness(opt, trace, *pol);

        if (cfg.count("out")) {
            std::ofstream o(cfg["out"]);
            o << "id,offset,size,arrival_ns,submit_ns,complete_ns,result,verify_ok\n";
            for (auto& x : r.records)
                o << x.id << ',' << x.offset << ',' << x.size << ',' << x.arrival_ns << ',' << x.submit_ns << ','
                  << x.complete_ns << ',' << x.result << ',' << int(x.verify_ok) << '\n';
        }
        if (tl) tl->write_csv(cfg["timeline"], pol->name);  // M2
        if (policy == "adaptive") {  // M3: every budget change, and a one-line summary
            if (cfg.count("adapt_log") && !g_ctl.write_log(cfg["adapt_log"]))
                throw std::runtime_error("cannot write " + cfg["adapt_log"]);
            std::printf("adaptive          : %zu budget changes in %llu windows, final level %d (%.0f us)\n", g_ctl.log().size(),
                        (unsigned long long)g_ctl.windows(), g_ctl.level(), g_ctl.budget_ns() / 1e3);
            // M3 Medur (3.2, 3.3): per-interval accounting, overshoot report and probes
            g_engine.finish();
            if (cfg.count("acct_log") && !g_engine.acct().write_csv(cfg["acct_log"]))
                throw std::runtime_error("cannot write " + cfg["acct_log"]);
            const auto t = g_engine.acct().totals();
            std::printf("allowance         : %.0f us per %.0f ms interval%s, %llu intervals, %llu over allowance, "
                        "max overshoot %.1f us, total overshoot %.1f us\n",
                        g_engine.acct().allowance_ns() / 1e3, g_engine.acct().interval_ns() / 1e6,
                        g_engine.acct().clip() ? " (clipped)" : "", (unsigned long long)t.intervals,
                        (unsigned long long)t.over, t.overshoot_max_ns / 1e3, t.overshoot_total_ns / 1e3);
            std::printf("spin accounting   : %llu spins (%llu hits), %llu cut short, %llu blocked by allowance, "
                        "spin %.1f ms, measured spin CPU %.1f ms, max spill %.1f us\n",
                        (unsigned long long)t.spins, (unsigned long long)t.hits, (unsigned long long)t.cut,
                        (unsigned long long)t.blocked, t.spin_ns / 1e6, t.spin_cpu_ns / 1e6, t.spill_max_ns / 1e3);
            std::printf("probes            : %llu probes (%llu hits) in %llu probing intervals\n",
                        (unsigned long long)t.probes, (unsigned long long)t.probe_hits,
                        (unsigned long long)g_engine.probes().rounds());
        }

        std::vector<uint64_t> lat, resp;
        for (auto& x : r.records) {
            if (x.complete_ns == 0 && x.result == -ECANCELED) continue;  // M2: never submitted (early stop)
            lat.push_back(x.complete_ns - x.submit_ns);    // device + completion latency
            resp.push_back(x.complete_ns - x.arrival_ns);  // includes any wait for a free slot
        }
        const double secs = r.wall_ns / 1e9;
        std::printf("policy            : %s\n", pol->name);
        const size_t ncomp = r.records.size() - r.not_submitted;  // M2
        std::printf("requests          : %zu\n", ncomp);
        if (r.stopped_early)
            std::printf("stopped early     : yes (%llu not submitted, %llu drained in flight)\n",
                        (unsigned long long)r.not_submitted, (unsigned long long)r.drained);
        std::printf("errors            : %llu\n", (unsigned long long)r.errors);
        std::printf("short reads       : %llu\n", (unsigned long long)r.short_reads);
        std::printf("verify failures   : %llu\n", (unsigned long long)r.verify_failures);
        std::printf("wall time         : %.3f s\n", secs);
        std::printf("reads per second  : %.0f\n", ncomp / secs);
        std::printf("latency p50 / p99 : %.1f / %.1f us  (submit->complete)\n", pct(lat, 0.50) / 1e3, pct(lat, 0.99) / 1e3);
        std::printf("response p50 / p99: %.1f / %.1f us  (arrival->complete)\n", pct(resp, 0.50) / 1e3, pct(resp, 0.99) / 1e3);
        std::printf("CPU time per read : %.2f us\n", ncomp == 0 ? 0.0 : r.cpu_ns / 1e3 / ncomp);
        std::printf("policy wait calls : %llu\n", (unsigned long long)r.waits);
        return (r.errors || r.verify_failures) ? 1 : 0;
    } catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
}
