// adaptive_controller.h - the rule of policy 4 (plan task 3.1, Pasha).
//
// Pure logic, no io_uring: it only looks at numbers from one accounting window and says which
// spin budget to use next. That keeps it easy to unit test (tests/test_controller.cpp), and lets
// Medur's accounting (3.2) and probes (3.3) and Sirisha's logging and tests (3.4) plug into the same
// two structs (WindowStats in, Adjustment out).
//
// Levels (the three calibrated budgets from calibration.conf, plus zero):
//     level 0 = no spinning (same as policy 1)     level 1 = short (p50 of a read)
//     level 2 = mid (p90)                          level 3 = long (p99)
//
// The rule, applied once at the end of every window of window_ns:
//   1. Lower:   if the spin time used >= the CPU allowance, go down one level ("allowance exceeded").
//   2. Lower:   if spinning rarely caught the completion (hit rate < down_hit), go down one level.
//   3. Raise:   if the hit rate has been >= up_hit for up_patience windows in a row AND the spin time used
//               stayed under headroom * allowance, try ONE level up ("productive"). Never right after a
//               lowering: cooldown windows must pass first, so it does not flip up and down.
//   4. Zero:    at level 0 nothing is spinning, so there is no hit rate. Occasional bounded probes
//               (task 3.3) say whether spinning would have caught the completion. If enough probes hit,
//               go back to level 1 ("probe hit").
// A "hit" means the completion showed up while the policy was spinning, so the spin paid off.
#pragma once
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

struct AdaptiveConfig {
    int64_t budgets_ns[4] = {0, 115000, 135000, 145000};  // level 0..3; levels 1-3 come from calibration.conf
    int64_t window_ns = 10000000;   // fixed accounting interval (10 ms)
    double allowance = 0.25;        // share of one window the policy may spend spinning (CPU allowance)
    int min_spins = 20;             // fewer spins than this in a window = too little evidence to act on hit rate
    double up_hit = 0.80;           // hit rate needed to count a window as "productive"
    double down_hit = 0.40;         // hit rate below this lowers the budget
    int up_patience = 3;            // productive windows in a row before trying a larger budget
    int cooldown = 3;               // windows after a lowering during which no raising is allowed
    double headroom = 0.60;         // only raise when spin time used <= headroom * allowance
    int start_level = 1;            // begin cautiously at the shortest non-zero budget
    int probe_min = 3;              // probes needed in one window before a zero budget may recover
    double probe_hit = 0.70;        // share of probes that must hit
    int probe_every = 5;            // at level 0, probe during one window out of every probe_every
    int probes_per_window = 8;      // at most this many probes in a probing window
    int probe_level = 2;            // probes spin for this level's budget (mid)
};

// What happened in one window (filled in by the policy; Medur's 3.2 accounting can fill the same fields).
struct WindowStats {
    uint64_t spins = 0;       // spin attempts that were not probes
    uint64_t hits = 0;        // of those, how many found a completion before the budget ran out
    uint64_t spin_ns = 0;     // time spent spinning in the window (spins and probes together)
    uint64_t probes = 0;      // bounded probes done at a zero budget
    uint64_t probe_hits = 0;  // of those, how many found a completion
};

// One budget change, for the log (task 3.4 records it, together with the measured checking time).
struct Adjustment {
    uint64_t window = 0;
    uint64_t t_ns = 0;
    int from = 0, to = 0;
    const char* reason = "";
    WindowStats stats;
    int64_t requested_allowance_ns = 0;
};

class AdaptiveController {
public:
    explicit AdaptiveController(const AdaptiveConfig& c = AdaptiveConfig()) { reset(c); }

    void reset(const AdaptiveConfig& c) {
        cfg_ = c;
        level_ = clamp(c.start_level);
        good_ = 0;
        cool_ = 0;
        window_ = 0;
        log_.clear();
    }

    int level() const { return level_; }
    int64_t budget_ns() const { return cfg_.budgets_ns[level_]; }
    int64_t allowance_ns() const { return static_cast<int64_t>(cfg_.allowance * static_cast<double>(cfg_.window_ns)); }
    const AdaptiveConfig& config() const { return cfg_; }
    const std::vector<Adjustment>& log() const { return log_; }
    uint64_t windows() const { return window_; }

    // Call once at the end of every window. Returns the new level (also available as level()).
    int update(const WindowStats& s, uint64_t t_ns = 0) {
        window_++;
        const int old = level_;
        const char* why = nullptr;
        const bool cooling = cool_ > 0;  // this window still falls inside the cooldown after a lowering
        if (cool_ > 0) cool_--;

        if (level_ > 0) {
            bool down = false;
            if (static_cast<int64_t>(s.spin_ns) >= allowance_ns()) {
                down = true;
                why = "allowance exceeded";
            } else if (s.spins >= static_cast<uint64_t>(cfg_.min_spins)) {
                const double hr = static_cast<double>(s.hits) / static_cast<double>(s.spins);
                if (hr < cfg_.down_hit) {
                    down = true;
                    why = "low hit rate";
                } else if (hr >= cfg_.up_hit && static_cast<double>(s.spin_ns) <= cfg_.headroom * static_cast<double>(allowance_ns())) {
                    good_++;
                    if (good_ >= cfg_.up_patience && !cooling && level_ < 3) {
                        level_++;
                        why = "productive";
                        good_ = 0;
                    }
                } else {
                    good_ = 0;
                }
            }
            if (down) {
                level_--;
                cool_ = cfg_.cooldown;
                good_ = 0;
            }
        } else if (s.probes >= static_cast<uint64_t>(cfg_.probe_min) &&
                   static_cast<double>(s.probe_hits) >= cfg_.probe_hit * static_cast<double>(s.probes)) {
            level_ = 1;
            why = "probe hit";
            good_ = 0;
        }

        if (level_ != old) {
            Adjustment a;
            a.window = window_;
            a.t_ns = t_ns;
            a.from = old;
            a.to = level_;
            a.reason = why ? why : "";
            a.stats = s;
            a.requested_allowance_ns = allowance_ns();
            log_.push_back(a);
        }
        return level_;
    }

    // CSV of every adjustment: when, from/to, why, and the numbers that caused it.
    bool write_log(const std::string& path) const {
        FILE* f = std::fopen(path.c_str(), "w");
        if (!f) return false;
        std::fprintf(f, "window,t_ns,from_level,to_level,budget_before_ns,budget_after_ns,reason,spins,hits,probes,probe_hits,"
                        "spin_ns_measured,allowance_ns_requested\n");
        for (const auto& a : log_)
            std::fprintf(f, "%llu,%llu,%d,%d,%lld,%lld,%s,%llu,%llu,%llu,%llu,%llu,%lld\n", (unsigned long long)a.window,
                         (unsigned long long)a.t_ns, a.from, a.to, (long long)cfg_.budgets_ns[a.from],
                         (long long)cfg_.budgets_ns[a.to], a.reason, (unsigned long long)a.stats.spins,
                         (unsigned long long)a.stats.hits, (unsigned long long)a.stats.probes,
                         (unsigned long long)a.stats.probe_hits, (unsigned long long)a.stats.spin_ns,
                         (long long)a.requested_allowance_ns);
        std::fclose(f);
        return true;
    }

private:
    static int clamp(int l) { return l < 0 ? 0 : (l > 3 ? 3 : l); }
    AdaptiveConfig cfg_;
    int level_ = 1, good_ = 0, cool_ = 0;
    uint64_t window_ = 0;
    std::vector<Adjustment> log_;
};
