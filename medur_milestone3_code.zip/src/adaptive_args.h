// adaptive_args.h - read policy 4 settings from named numbers (calibration.conf keys or command-line keys).
// Shared by run_bench (single run) and studya (task 3.5), so both set the controller the same way.
#pragma once
#include <stdexcept>

#include "adaptive_controller.h"
#include "adaptive_engine.h"  // M3 Medur: AcctConfig

// get(key, default) must return the number for key, or the default when it was not given.
template <class Get>
inline AdaptiveConfig adaptive_config_from(Get get) {
    AdaptiveConfig ac;
    ac.budgets_ns[1] = static_cast<int64_t>(get("spin_short_us", get("short_us", 115)) * 1000.0);
    ac.budgets_ns[2] = static_cast<int64_t>(get("spin_mid_us", get("mid_us", 135)) * 1000.0);
    ac.budgets_ns[3] = static_cast<int64_t>(get("spin_long_us", get("long_us", 145)) * 1000.0);
    ac.window_ns = static_cast<int64_t>(get("ctl_window_ms", 10) * 1e6);
    ac.allowance = get("allowance_pct", 25) / 100.0;
    ac.min_spins = static_cast<int>(get("min_spins", ac.min_spins));
    ac.up_hit = get("up_hit", ac.up_hit);
    ac.down_hit = get("down_hit", ac.down_hit);
    ac.up_patience = static_cast<int>(get("up_patience", ac.up_patience));
    ac.cooldown = static_cast<int>(get("cooldown", ac.cooldown));
    ac.headroom = get("headroom", ac.headroom);
    ac.start_level = static_cast<int>(get("start_level", ac.start_level));
    ac.probe_every = static_cast<int>(get("probe_every", ac.probe_every));
    ac.probes_per_window = static_cast<int>(get("probes_per_window", ac.probes_per_window));  // M3 Medur (3.3)
    ac.probe_level = static_cast<int>(get("probe_level", ac.probe_level));                    // M3 Medur (3.3)
    if (!(ac.budgets_ns[1] > 0 && ac.budgets_ns[1] < ac.budgets_ns[2] && ac.budgets_ns[2] < ac.budgets_ns[3]))
        throw std::runtime_error("adaptive budgets must be increasing and above zero");
    if (ac.start_level < 0 || ac.start_level > 3) throw std::runtime_error("start_level must be 0 to 3");
    if (ac.allowance < 0 || ac.allowance > 1) throw std::runtime_error("allowance_pct must be 0 to 100");  // M3 Medur
    if (ac.probe_level < 1 || ac.probe_level > 3) throw std::runtime_error("probe_level must be 1 to 3");  // M3 Medur
    return ac;
}

// M3 Medur (tasks 3.2 and 3.3): allowance_clip (0/1), measure_spin_cpu (0/1), probe_backoff (>= 1).
template <class Get>
inline AcctConfig acct_config_from(Get get) {
    AcctConfig mc;
    mc.clip = get("allowance_clip", 0) != 0;
    mc.measure_cpu = get("measure_spin_cpu", 1) != 0;
    mc.probe_backoff = static_cast<int>(get("probe_backoff", mc.probe_backoff));
    if (mc.probe_backoff < 1) throw std::runtime_error("probe_backoff must be at least 1");
    return mc;
}
