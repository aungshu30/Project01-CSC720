// policy_adaptive.h - policy 4: adaptive spin budget (Milestone 3).
//
//   rule (3.1, Pasha)            adaptive_controller.h
//   allowance (3.2, Medur)       cpu_allowance.h       - replaces Pasha's stand-in
//   probes (3.3, Medur)          probe_scheduler.h     - replaces Pasha's stand-in
//   joined in                    adaptive_engine.h
//
// The I/O path is the same as policy 3 (peek for at most the budget, then sleep for the rest), so any
// difference in results comes from the budget decisions, not from new I/O code.
// Names used by run_bench and studya are kept: g_adapt_cfg, g_ctl, adaptive_reset(), kPolicyAdaptive.
#pragma once
#include <cerrno>
#include <ctime>

#include "adaptive_controller.h"
#include "adaptive_engine.h"
#include "common.h"
#include "harness_state.h"
#include "policy_wait.h"

inline AdaptiveConfig g_adapt_cfg;   // 3.1 settings (run_bench / studya fill it from the config)
inline AcctConfig g_acct_cfg;        // 3.2 / 3.3 settings (same)
inline AdaptiveController g_ctl;     // the rule; its budget-change log is written by run_bench / studya
inline AdaptiveEngine g_engine;      // allowance + probes + rule

inline void adaptive_reset() {
    g_engine.reset(g_adapt_cfg, g_acct_cfg, &g_ctl);
    g_budget_ns = g_ctl.budget_ns();
}

inline uint64_t adaptive_thread_cpu_ns() {
    timespec ts;
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    return static_cast<uint64_t>(ts.tv_sec) * 1000000000ull + static_cast<uint64_t>(ts.tv_nsec);
}

inline int policy_adaptive_wait(struct io_uring* ring, struct io_uring_cqe** cqe, int64_t timeout_ns) {
    *cqe = nullptr;
    const uint64_t t_in = now_ns();
    g_engine.tick(t_in);                 // close finished intervals even when nothing is in flight
    g_budget_ns = g_engine.budget_ns();  // the over-time recorder (timeline.h) reads this

    if (g_inflight == 0) return policy_wait_immediately(ring, cqe, timeout_ns);  // nothing to spin for

    const SpinPlan p = g_engine.plan(t_in, timeout_ns);
    if (p.budget_ns > 0) {
        const bool cpu = g_acct_cfg.measure_cpu;
        const uint64_t c0 = cpu ? adaptive_thread_cpu_ns() : 0;
        const uint64_t t0 = now_ns();
        bool hit = false;
        while (static_cast<int64_t>(now_ns() - t0) < p.budget_ns) {
            const int r = io_uring_peek_cqe(ring, cqe);
            if (r == 0) { hit = true; break; }
            if (r != -EAGAIN) break;
        }
        const uint64_t t1 = now_ns();
        const uint64_t c1 = cpu ? adaptive_thread_cpu_ns() : 0;
        g_engine.done(p, t0, t1, c1 - c0, hit);
        if (hit) return 0;
        *cqe = nullptr;
    }
    int64_t rest = -1;
    if (timeout_ns >= 0) {
        rest = timeout_ns - static_cast<int64_t>(now_ns() - t_in);
        if (rest < 0) rest = 0;
    }
    return policy_wait_immediately(ring, cqe, rest);
}

inline const Policy kPolicyAdaptive = {"adaptive", policy_adaptive_wait};
