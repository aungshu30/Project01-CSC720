// policies.h - pick a policy by name.
#pragma once
#include <string>

#include "policy_adaptive.h"
#include "policy_poll.h"
#include "policy_spin.h"
#include "policy_wait.h"

// name: "wait", "poll", "spin" or "adaptive". For "spin", spin_us is the fixed spin time in microseconds.
// For "adaptive", fill g_adapt_cfg first (budgets, window, allowance); this resets the controller.
inline const Policy* pick_policy(const std::string& name, double spin_us = 0) {
    if (name == "wait") return &kPolicyWaitImmediately;
    if (name == "poll") return &kPolicyPoll;
    if (name == "spin") { g_spin_ns = static_cast<int64_t>(spin_us * 1000.0); return &kPolicySpin; }
    if (name == "adaptive") { adaptive_reset(); return &kPolicyAdaptive; }
    return nullptr;
}
