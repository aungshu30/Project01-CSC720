// adaptive_engine.h - joins the three parts of policy 4 (Milestone 3):
//   * the rule                       adaptive_controller.h  (task 3.1, Pasha)   - unchanged
//   * fixed interval + CPU allowance cpu_allowance.h        (task 3.2, Medur)
//   * bounded probes at zero budget  probe_scheduler.h      (task 3.3, Medur)
//
// Pure logic, no io_uring: the policy (policy_adaptive.h) asks plan() before a spin and calls done()
// after it, passing the times. The tests drive the same engine with a fake clock.
//
// Before each spin:   SpinPlan p = engine.plan(now, timeout_ns);
//                     if (p.budget_ns > 0) { spin for at most p.budget_ns; engine.done(p, t0, t1, cpu, hit); }
#pragma once
#include <cstdint>

#include "adaptive_controller.h"
#include "cpu_allowance.h"
#include "probe_scheduler.h"

// Settings that belong to tasks 3.2 and 3.3 (the rest are in AdaptiveConfig).
struct AcctConfig {
    bool clip = false;          // 3.2: shorten a spin to the allowance left (no overshoot). Default off: the plan
                                //      says "stop starting new spins", and the overshoot is reported instead.
    bool measure_cpu = true;    // 3.2: measure thread CPU during each spin (2 clock reads per spin, ~0.3 us)
    int probe_backoff = 4;      // 3.3: probe gap may grow up to probe_every * probe_backoff (1 = off)
};

struct SpinPlan {
    int64_t budget_ns = 0;   // 0 = do not spin, just sleep
    int64_t wanted_ns = 0;   // what the level (or probe) asked for, before allowance / deadline limits
    bool probe = false;      // this spin is a bounded probe at a zero budget
    bool blocked = false;    // not started because the allowance was used up
};

class AdaptiveEngine {
public:
    // ctl must outlive the engine (policy_adaptive.h passes the global g_ctl, so run_bench and studya
    // still read the budget log from g_ctl as before).
    void reset(const AdaptiveConfig& ac, const AcctConfig& mc, AdaptiveController* ctl) {
        ac_ = ac;
        mc_ = mc;
        ctl_ = ctl;
        ctl_->reset(ac);
        acct_.reset(ac.window_ns, ctl_->allowance_ns(), mc.clip);
        ProbeConfig pc;
        pc.every = ac.probe_every;
        pc.per_interval = ac.probes_per_window;
        pc.backoff = mc.probe_backoff;
        probes_.reset(pc);
        probe_level_ = ac.probe_level < 1 ? 1 : (ac.probe_level > 3 ? 3 : ac.probe_level);
    }

    // Move the clock: close every finished interval and let the controller pick the next level.
    void tick(uint64_t now) {
        const bool first = !acct_.started();
        acct_.advance(now, [&](const IntervalStats& closed, IntervalStats& next) {
            WindowStats w;
            w.spins = closed.spins;
            w.hits = closed.hits;
            w.spin_ns = closed.spin_ns;
            w.probes = closed.probes;
            w.probe_hits = closed.probe_hits;
            ctl_->update(w, closed.start_ns + acct_.interval_ns());  // t_ns = end of that interval, run-relative
            stamp(next);
            probes_.next_interval(ctl_->level(), closed.probes);
        });
        if (first) {
            stamp(acct_.current());
            probes_.next_interval(ctl_->level(), 0);
        }
    }

    // Decide the spin for this wait. timeout_ns < 0 = no deadline, else the next arrival is due then.
    SpinPlan plan(uint64_t now, int64_t timeout_ns) {
        tick(now);
        SpinPlan p;
        int64_t want = ctl_->budget_ns();
        if (want == 0) {
            if (!probes_.available()) return p;            // level 0 and not a probing moment: just sleep
            want = ac_.budgets_ns[probe_level_];
            p.probe = true;
        }
        p.wanted_ns = want;
        int64_t b = acct_.limit(want);                     // 3.2: no new spin once the allowance is used up
        if (b <= 0) {
            p.blocked = true;
            p.probe = false;
            acct_.current().blocked++;
            return p;
        }
        if (timeout_ns >= 0 && timeout_ns < b) b = timeout_ns;  // the harness must submit the next read on time
        if (b <= 0) { p.probe = false; return p; }
        if (p.probe) probes_.take();
        p.budget_ns = b;
        return p;
    }

    // Report how a planned spin went. t_start / t_end are absolute ns; cpu_ns is thread CPU during it.
    void done(const SpinPlan& p, uint64_t t_start, uint64_t t_end, uint64_t cpu_ns, bool hit) {
        if (p.budget_ns <= 0) return;
        acct_.charge(t_start, t_end, cpu_ns);
        IntervalStats& s = acct_.current();
        const bool shortened = p.budget_ns < p.wanted_ns;  // cut by the next arrival or by clipping
        if (!hit && shortened) {      // says nothing about whether the full budget would have caught it
            s.cut++;
            return;
        }
        if (p.probe) {
            s.probes++;
            if (hit) s.probe_hits++;
        } else {
            s.spins++;
            if (hit) s.hits++;
        }
    }

    void finish() { acct_.flush(); }  // call at the end of a run so the last interval is logged

    const CpuAllowance& acct() const { return acct_; }
    const ProbeScheduler& probes() const { return probes_; }
    const AdaptiveController& controller() const { return *ctl_; }
    const AcctConfig& acct_config() const { return mc_; }
    int64_t budget_ns() const { return ctl_->budget_ns(); }

private:
    void stamp(IntervalStats& s) const {
        s.level = ctl_->level();
        s.budget_ns = ctl_->budget_ns();
        s.allowance_ns = acct_.allowance_ns();
    }

    AdaptiveConfig ac_;
    AcctConfig mc_;
    AdaptiveController* ctl_ = nullptr;
    CpuAllowance acct_;
    ProbeScheduler probes_;
    int probe_level_ = 2;
};
