// probe_scheduler.h - occasional bounded probes at a zero budget (plan task 3.3, Medur).
//
// Problem: at level 0 the policy never spins, so it never learns whether spinning would pay off
// again after the traffic changes. A probe is one short spin, done on purpose at a zero budget,
// to find out. Pasha's controller (adaptive_controller.h, rule 4) reads the probe results and goes
// back to level 1 when enough probes hit.
//
// "Occasional": only one interval out of every `gap` intervals is a probing interval.
//               gap starts at probe_every (default 5 = every 50 ms with 10 ms intervals).
//               If a probing round does not bring the budget back, gap doubles (back-off), up to
//               probe_every * probe_backoff (default 4x = every 200 ms). It resets as soon as the
//               level is above zero again. probe_backoff = 1 turns the back-off off.
// "Bounded":    at most probes_per_window probes in a probing interval (default 8), each lasting at
//               most the probe budget (default level 2 = mid), and probes are charged to the same CPU
//               allowance as normal spins (task 3.2), so they stop when the allowance is used up.
//               Worst case per probing interval: 8 x 135 us = 1.08 ms of a 10 ms interval.
//
// Pure logic, no io_uring and no clock: tested in tests/test_allowance_probe.cpp.
#pragma once
#include <cstdint>

struct ProbeConfig {
    int every = 5;          // probe in one interval out of every `every` (0 = never probe)
    int per_interval = 8;   // max probes in a probing interval
    int backoff = 4;        // gap may grow up to every * backoff after failed rounds (1 = no back-off)
};

class ProbeScheduler {
public:
    void reset(const ProbeConfig& c) {
        cfg_ = c;
        if (cfg_.backoff < 1) cfg_.backoff = 1;
        gap_ = cfg_.every;
        count_ = 0;
        left_ = 0;
        rounds_ = 0;
    }

    // Called when a new interval opens. `level` is the controller level for this new interval,
    // `probes_last` is how many probes were done in the interval that just closed.
    void next_interval(int level, uint64_t probes_last) {
        left_ = 0;
        if (level > 0) {  // spinning again: forget the back-off, start fresh next time we hit zero
            gap_ = cfg_.every;
            count_ = 0;
            return;
        }
        if (cfg_.every <= 0 || cfg_.per_interval <= 0) return;
        if (probes_last > 0) {  // we probed and are still at zero: wait longer before the next round
            const int max_gap = cfg_.every * cfg_.backoff;
            gap_ = gap_ * 2 > max_gap ? max_gap : gap_ * 2;
        }
        if (++count_ >= gap_) {
            count_ = 0;
            left_ = cfg_.per_interval;
            rounds_++;
        }
    }

    bool available() const { return left_ > 0; }  // may a probe be done now?
    void take() { if (left_ > 0) left_--; }       // one probe used
    int gap() const { return gap_; }               // current spacing in intervals
    uint64_t rounds() const { return rounds_; }   // probing intervals so far
    const ProbeConfig& config() const { return cfg_; }

private:
    ProbeConfig cfg_;
    int gap_ = 5;
    int count_ = 0;
    int left_ = 0;
    uint64_t rounds_ = 0;
};
