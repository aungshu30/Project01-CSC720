// cpu_allowance.h - fixed accounting interval and CPU allowance for policy 4 (plan task 3.2, Medur).
//
// Pure logic, no io_uring: the caller passes in the times, so it can be unit tested with a fake clock
// (tests/test_allowance_probe.cpp).
//
// How it works
//   * Time is cut into FIXED intervals of interval_ns (default 10 ms) on a grid that starts at the
//     first call: interval k covers [origin + k*interval_ns, origin + (k+1)*interval_ns). The grid
//     never drifts, even if the thread sleeps across several intervals.
//   * Each interval has a CPU allowance (allowance_ns, default 25% of the interval) for checking.
//     Every spin and every probe is charged to the interval in which it STARTED.
//   * Once the spin time of the current interval reaches the allowance, no new spin is started
//     (can_start() == false). The policy then just sleeps (policy 1 behaviour) until the next interval.
//   * A spin that started just before the allowance ran out can finish after it. That extra time is
//     the "overshoot" and is reported per interval. It is at most one spin budget. With clip = true,
//     a spin is shortened to the allowance that is left, so there is no overshoot.
//   * A spin that started near the end of an interval can run past the interval end. That time is
//     the "spill" and is also reported (it is still charged to the interval where it started).
//   * Per interval we also keep the thread CPU measured during spins (spin_cpu_ns). This is the
//     "measured checking CPU" next to the "requested allowance" that task 3.4 asks for.
#pragma once
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

// Everything we know about one accounting interval. One row of the --acct_log CSV.
struct IntervalStats {
    uint64_t index = 0;          // interval number on the fixed grid
    uint64_t start_ns = 0;       // start, relative to the first call
    int level = 0;               // controller level in force during this interval
    int64_t budget_ns = 0;       // spin budget of that level
    int64_t allowance_ns = 0;    // requested CPU allowance for this interval
    uint64_t spin_ns = 0;        // time spent spinning (spins + probes), what is charged
    uint64_t spin_cpu_ns = 0;    // thread CPU measured during those spins (0 if not measured)
    uint64_t spins = 0;          // normal spins that count for the hit rate
    uint64_t hits = 0;           // of those, how many caught the completion
    uint64_t cut = 0;            // spins cut short (next arrival due, or clipped) that missed: not counted as misses
    uint64_t probes = 0;         // bounded probes at a zero budget (task 3.3)
    uint64_t probe_hits = 0;     // of those, how many caught the completion
    uint64_t blocked = 0;        // spins NOT started because the allowance was used up
    uint64_t overshoot_ns = 0;   // spin_ns above the allowance (0 if within)
    uint64_t spill_ns = 0;       // spin time that ran past the end of this interval
};

class CpuAllowance {
public:
    void reset(int64_t interval_ns, int64_t allowance_ns, bool clip) {
        interval_ = interval_ns > 0 ? static_cast<uint64_t>(interval_ns) : 10000000ull;
        allowance_ = allowance_ns < 0 ? 0 : allowance_ns;
        clip_ = clip;
        started_ = false;
        origin_ = 0;
        cur_ = IntervalStats();
        cur_.allowance_ns = allowance_;
        log_.clear();
        log_.reserve(4096);
    }

    bool started() const { return started_; }
    uint64_t origin() const { return origin_; }
    uint64_t interval_ns() const { return interval_; }
    int64_t allowance_ns() const { return allowance_; }
    bool clip() const { return clip_; }
    IntervalStats& current() { return cur_; }
    const IntervalStats& current() const { return cur_; }
    const std::vector<IntervalStats>& log() const { return log_; }

    // End time (absolute) of the current interval.
    uint64_t current_end() const { return origin_ + (cur_.index + 1) * interval_; }

    // Move the clock to `now` (absolute ns). Every interval that has ended is closed, saved in the
    // log, and handed to on_close(closed, next) in order; `next` is the fresh interval that follows,
    // so the caller can stamp the level and budget on it. Returns how many intervals were closed.
    template <class F>
    size_t advance(uint64_t now, F&& on_close) {
        if (!started_) {
            started_ = true;
            origin_ = now;
            cur_ = IntervalStats();
            cur_.allowance_ns = allowance_;
            return 0;
        }
        if (now < origin_) return 0;
        const uint64_t idx = (now - origin_) / interval_;
        size_t closed = 0;
        while (cur_.index < idx) {
            finish(cur_);
            log_.push_back(cur_);
            IntervalStats next;
            next.index = cur_.index + 1;
            next.start_ns = next.index * interval_;
            next.allowance_ns = allowance_;
            on_close(log_.back(), next);
            cur_ = next;
            closed++;
        }
        return closed;
    }

    // May a new spin start now?  (allowance 0 = never)
    bool can_start() const { return static_cast<int64_t>(cur_.spin_ns) < allowance_; }

    // How long may a spin that wants `budget` ns run in this interval? 0 = do not start.
    int64_t limit(int64_t budget) const {
        if (budget <= 0 || !can_start()) return 0;
        if (!clip_) return budget;
        const int64_t left = allowance_ - static_cast<int64_t>(cur_.spin_ns);
        return budget < left ? budget : left;
    }

    // Charge one spin that ran from t_start to t_end (absolute ns) to the current interval.
    void charge(uint64_t t_start, uint64_t t_end, uint64_t cpu_ns) {
        if (t_end < t_start) t_end = t_start;
        cur_.spin_ns += t_end - t_start;
        cur_.spin_cpu_ns += cpu_ns;
        const uint64_t end = current_end();
        if (t_end > end) cur_.spill_ns += t_end - (t_start > end ? t_start : end);
    }

    // Close the last (partial) interval at the end of a run, so it shows up in the log.
    void flush() {
        if (!started_) return;
        finish(cur_);
        log_.push_back(cur_);
        started_ = false;
    }

    // Totals over the log, for the one-line summary.
    struct Totals {
        uint64_t intervals = 0, over = 0, blocked = 0, probes = 0, probe_hits = 0, spins = 0, hits = 0, cut = 0;
        uint64_t overshoot_total_ns = 0, overshoot_max_ns = 0, spill_total_ns = 0, spill_max_ns = 0;
        uint64_t spin_ns = 0, spin_cpu_ns = 0;
    };
    Totals totals() const {
        Totals t;
        for (const auto& s : log_) {
            t.intervals++;
            if (s.overshoot_ns > 0) t.over++;
            t.blocked += s.blocked;
            t.probes += s.probes;
            t.probe_hits += s.probe_hits;
            t.spins += s.spins;
            t.hits += s.hits;
            t.cut += s.cut;
            t.overshoot_total_ns += s.overshoot_ns;
            if (s.overshoot_ns > t.overshoot_max_ns) t.overshoot_max_ns = s.overshoot_ns;
            t.spill_total_ns += s.spill_ns;
            if (s.spill_ns > t.spill_max_ns) t.spill_max_ns = s.spill_ns;
            t.spin_ns += s.spin_ns;
            t.spin_cpu_ns += s.spin_cpu_ns;
        }
        return t;
    }

    // One row per interval. Hook for task 3.4 (Sirisha): requested allowance next to measured checking CPU.
    bool write_csv(const std::string& path) const {
        FILE* f = std::fopen(path.c_str(), "w");
        if (!f) return false;
        std::fprintf(f, "interval,start_s,level,budget_ns,allowance_ns,spin_ns,spin_cpu_ns,spins,hits,cut,probes,probe_hits,"
                        "blocked,overshoot_ns,spill_ns\n");
        for (const auto& s : log_)
            std::fprintf(f, "%llu,%.6f,%d,%lld,%lld,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu\n",
                         (unsigned long long)s.index, s.start_ns / 1e9, s.level, (long long)s.budget_ns,
                         (long long)s.allowance_ns, (unsigned long long)s.spin_ns, (unsigned long long)s.spin_cpu_ns,
                         (unsigned long long)s.spins, (unsigned long long)s.hits, (unsigned long long)s.cut,
                         (unsigned long long)s.probes, (unsigned long long)s.probe_hits, (unsigned long long)s.blocked,
                         (unsigned long long)s.overshoot_ns, (unsigned long long)s.spill_ns);
        std::fclose(f);
        return true;
    }

private:
    void finish(IntervalStats& s) const {
        const int64_t over = static_cast<int64_t>(s.spin_ns) - allowance_;
        s.overshoot_ns = over > 0 ? static_cast<uint64_t>(over) : 0;
    }

    uint64_t interval_ = 10000000ull;
    int64_t allowance_ = 2500000;
    bool clip_ = false;
    bool started_ = false;
    uint64_t origin_ = 0;
    IntervalStats cur_;
    std::vector<IntervalStats> log_;
};
