// studya - plan task 3.5 (Pasha): Study A, steady load, policies 1 to 4, light and moderate, 3 repetitions.
//
// Policies: wait (1), poll (2), spin at the three calibrated durations (3), adaptive (4).
// For every run it collects p50 and p99 latency, reads per second and CPU time per read, checks every read,
// and for policy 4 saves the budget-change log (task 3.4 format) and how long it spent at each level.
// Every run replays the SAME trace (same seed) and runs go round-robin (repeat 1 of everything, then
// repeat 2, ...) so slow drift hits all policies alike.
//
//   ./studya --file test.bin --loads loads.conf --calib calibration.conf --duration 10 --reps 3 --outdir studya_out
#include <sys/stat.h>

#include <cmath>
#include <cstdio>
#include <map>

#include "adaptive_args.h"
#include "conf.h"
#include "policies.h"
#include "summary.h"

struct Variant { std::string label, policy; double spin_us; };

int main(int argc, char** argv) {
    try {
        Args a(argc, argv, {"loads", "calib"});
        HarnessOptions opt;
        opt.file = a.str("file");
        opt.depth = static_cast<unsigned>(a.num("depth", 32));
        opt.direct = a.num("direct", 1) != 0;
        const double dur = a.num("duration", 10);
        const int reps = static_cast<int>(a.num("reps", 3));
        const uint64_t seed = static_cast<uint64_t>(a.num("seed", 1));
        const std::string outdir = a.str("outdir", "studya_out");
        ::mkdir(outdir.c_str(), 0755);
        std::vector<std::pair<std::string, double>> loads = {{"light", a.num("light_rps")}, {"moderate", a.num("moderate_rps")}};
        std::vector<Variant> vars = {{"1 wait", "wait", 0}, {"2 poll", "poll", 0}};
        const char* names[3] = {"spin_short_us", "spin_mid_us", "spin_long_us"};
        for (int i = 0; i < 3; i++) {
            double us = a.num(names[i]);
            char lab[64]; std::snprintf(lab, sizeof lab, "3 spin %.0fus", us);
            vars.push_back({lab, "spin", us});
        }
        vars.push_back({"4 adaptive", "adaptive", 0});
        g_adapt_cfg = adaptive_config_from([&](const char* k, double d) { return a.num(k, d); });
        g_acct_cfg = acct_config_from([&](const char* k, double d) { return a.num(k, d); });  // M3 Medur

        wl::Config wc;
        wc.seed = seed;
        wc.file_size = file_size_of(opt.file);
        std::map<std::string, std::vector<wl::Request>> traces;
        for (auto& l : loads) traces[l.first] = wl::generate_steady(wc, l.second, dur);

        const std::string out = outdir + "/study_a_results.csv";
        FILE* f = std::fopen(out.c_str(), "w");
        if (!f) throw std::runtime_error("cannot write " + out);
        std::fprintf(f, "load,rate_rps,policy,repeat,reads,reads_per_s,lat_p50_us,lat_p99_us,resp_p50_us,resp_p99_us,cpu_us_per_read,"
                        "errors,short_reads,verify_failures,budget_changes,final_level\n");
        std::map<std::string, std::vector<Summary>> acc;  // key: load|policy
        bool bad = false;
        for (int r = 1; r <= reps; r++)
            for (auto& l : loads)
                for (auto& v : vars) {
                    const Policy* pol = pick_policy(v.policy, v.spin_us);
                    Summary s = summarize(run_harness(opt, traces[l.first], *pol));
                    size_t changes = 0; int final_level = -1;
                    if (v.policy == "adaptive") {
                        changes = g_ctl.log().size(); final_level = g_ctl.level();
                        char lp[256];
                        std::snprintf(lp, sizeof lp, "%s/adapt_log_%s_rep%d.csv", outdir.c_str(), l.first.c_str(), r);
                        g_ctl.write_log(lp);
                        g_engine.finish();  // M3 Medur: per-interval allowance log next to the budget log
                        std::snprintf(lp, sizeof lp, "%s/acct_log_%s_rep%d.csv", outdir.c_str(), l.first.c_str(), r);
                        g_engine.acct().write_csv(lp);
                    }
                    std::printf("repeat %d  %-8s %-14s  p50 %7.1f  p99 %7.1f us  %7.0f reads/s  CPU %6.2f us/read%s\n", r, l.first.c_str(),
                                v.label.c_str(), s.lat_p50_us, s.lat_p99_us, s.rps, s.cpu_us_per_read,
                                (s.errors || s.verify_failures || s.short_reads) ? "  ** PROBLEM **" : "");
                    std::fflush(stdout);
                    std::fprintf(f, "%s,%.0f,%s,%d,%zu,%.0f,%.1f,%.1f,%.1f,%.1f,%.2f,%llu,%llu,%llu,%zu,%d\n", l.first.c_str(), l.second, v.label.c_str(), r, s.n,
                                 s.rps, s.lat_p50_us, s.lat_p99_us, s.resp_p50_us, s.resp_p99_us, s.cpu_us_per_read,
                                 (unsigned long long)s.errors, (unsigned long long)s.short_reads, (unsigned long long)s.verify_failures, changes, final_level);
                    if (s.errors || s.short_reads || s.verify_failures) bad = true;
                    acc[l.first + "|" + v.label].push_back(s);
                }
        std::fclose(f);

        std::printf("\n===== Study A: mean over %d repeats (min-max in brackets) =====\n", reps);
        for (auto& l : loads) {
            std::printf("\n%s load: %.0f reads/s for %.0f s\n%-14s %19s %19s %17s %19s\n", l.first.c_str(), l.second, dur, "policy", "p50 us", "p99 us", "reads/s", "CPU us/read");
            for (auto& v : vars) {
                auto& xs = acc[l.first + "|" + v.label];
                auto stat = [&](double Summary::*m, char* buf, size_t n, const char* fmt) {
                    double lo = 1e18, hi = -1e18, sum = 0;
                    for (auto& s : xs) { lo = std::min(lo, s.*m); hi = std::max(hi, s.*m); sum += s.*m; }
                    char t[64]; std::snprintf(t, sizeof t, fmt, sum / xs.size(), lo, hi); std::snprintf(buf, n, "%s", t);
                };
                char b1[64], b2[64], b3[64], b4[64];
                stat(&Summary::lat_p50_us, b1, 64, "%.1f (%.1f-%.1f)"); stat(&Summary::lat_p99_us, b2, 64, "%.1f (%.1f-%.1f)");
                stat(&Summary::rps, b3, 64, "%.0f (%.0f-%.0f)"); stat(&Summary::cpu_us_per_read, b4, 64, "%.2f (%.2f-%.2f)");
                std::printf("%-14s %19s %19s %17s %19s\n", v.label.c_str(), b1, b2, b3, b4);
            }
        }
        std::printf("\nwrote %s and the adaptive logs  (%s)\n", out.c_str(), bad ? "SOME READS FAILED - see ** PROBLEM ** lines" : "all reads correct");
        return bad ? 1 : 0;
    } catch (const std::exception& e) { std::fprintf(stderr, "error: %s\n", e.what()); return 1; }
}
