#!/bin/bash
# summarize_studyb_m3.sh - tables for Study B, Milestone 3 (task 3.6, Medur). Only uses awk.
#   ./summarize_studyb_m3.sh results/m3_studyb_<time> [expected_requests]
# Writes in that folder:
#   studyb_results.csv         one row per run (whole-trace numbers, plus policy 4 accounting)
#   studyb_phases_by_run.csv   one row per run and trace phase (CPU, budget, pending, latency over time)
# and prints the mean (min-max) tables.
set -u
OUT=${1:?usage: summarize_studyb_m3.sh RESULTS_DIR [expected_requests]}
EXP=${2:-}
[ -d "$OUT/runs" ] || { echo "no $OUT/runs folder"; exit 2; }

# ---- 1. one row per run, from the run_bench summaries
R=$OUT/studyb_results.csv
echo "label,policy,rep,order,requests,expected,errors,short_reads,verify_failures,wall_s,reads_per_s,lat_p50_us,lat_p99_us,resp_p50_us,resp_p99_us,cpu_us_per_read,budget_changes,final_level,spins,hits,cut,blocked,over_intervals,max_overshoot_us,probes,probe_hits" > "$R"
tail -n +2 "$OUT/run_order.csv" | while IFS=, read -r L P REP ORD RC; do
    f=$OUT/runs/summary_${L}_rep${REP}.txt
    [ -f "$f" ] || continue
    awk -v L="$L" -v P="$P" -v REP="$REP" -v ORD="$ORD" -v EXP="$EXP" '
      function num(s) { gsub(/[^0-9.\-]/, "", s); return s }
      /^requests /          { split($0, a, ":"); req = num(a[2]) }
      /^errors /            { split($0, a, ":"); err = num(a[2]) }
      /^short reads /       { split($0, a, ":"); sr = num(a[2]) }
      /^verify failures /   { split($0, a, ":"); vf = num(a[2]) }
      /^wall time /         { split($0, a, ":"); split(a[2], b, " "); wall = b[1] }
      /^reads per second /  { split($0, a, ":"); rps = num(a[2]) }
      /^latency p50/        { split($0, a, ":"); split(a[2], b, " "); l50 = b[1]; l99 = b[3] }
      /^response p50/       { split($0, a, ":"); split(a[2], b, " "); r50 = b[1]; r99 = b[3] }
      /^CPU time per read / { split($0, a, ":"); split(a[2], b, " "); cpu = b[1] }
      /^adaptive /          { split($0, a, ":"); n = split(a[2], b, " "); bc = b[1]; for (i = 1; i <= n; i++) if (b[i] == "level") fl = b[i + 1] }
      /^allowance /         { split($0, a, ":"); n = split(a[2], b, ","); for (i = 1; i <= n; i++) {
                                if (b[i] ~ /over allowance/) { split(b[i], c, " "); ov = c[1] }
                                if (b[i] ~ /max overshoot/)  { split(b[i], c, " "); mo = c[3] } } }
      /^spin accounting /   { split($0, a, ":"); n = split(a[2], b, ","); for (i = 1; i <= n; i++) {
                                if (b[i] ~ /spins \(/)   { split(b[i], c, " "); sp = c[1]; h = c[3]; gsub(/\(/, "", h); hi = h }
                                if (b[i] ~ /cut short/)  { split(b[i], c, " "); cu = c[1] }
                                if (b[i] ~ /blocked/)    { split(b[i], c, " "); bl = c[1] } } }
      /^probes /            { split($0, a, ":"); split(a[2], b, " "); pr = b[1]; ph = b[3]; gsub(/\(/, "", ph) }
      END {
        printf "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n", L, P, REP, ORD, req, EXP, err, sr, vf, wall, rps,
               l50, l99, r50, r99, cpu, bc, fl, sp, hi, cu, bl, ov, mo, pr, ph
      }' "$f" >> "$R"
done

# ---- 2. one row per run and phase, from the timelines (window -> phase by its start time)
PH=$OUT/studyb_phases_by_run.csv
if [ -f "$OUT/studyb_phases.csv" ]; then
    echo "label,rep,phase,kind,start_s,end_s,windows,completions,mean_cpu_util,mean_budget_us,unlimited_windows,max_pending,max_inflight,p99_of_window_resp_p99_us" > "$PH"
    for t in "$OUT"/runs/timeline_*_rep*.csv; do
        [ -f "$t" ] || continue
        b=$(basename "$t" .csv); b=${b#timeline_}; L=${b%_rep*}; REP=${b##*_rep}
        awk -F, -v L="$L" -v REP="$REP" '
          NR == FNR { if (FNR > 1) { np++; pid[np] = $1; pk[np] = $2; ps[np] = $3; pe[np] = $4 } next }
          FNR == 1 { next }
          { s = $3 + 0; ph = 0
            for (i = 1; i <= np; i++) if (s >= ps[i] - 1e-9 && s < pe[i] - 1e-9) { ph = i; break }
            if (!ph) next
            w[ph]++; comp[ph] += $11; cpu[ph] += $7
            if ($5 >= 0) { bud[ph] += $5 / 1000; nb[ph]++ } else unl[ph]++
            if ($16 > mp[ph]) mp[ph] = $16
            if ($17 > mi[ph]) mi[ph] = $17
            if ($11 > 0) { nr[ph]++; rv[ph, nr[ph]] = $15 + 0 } }
          END {
            for (i = 1; i <= np; i++) {
              # 99th percentile over the windows of this phase of the per-window response p99
              n = nr[i]; for (a = 2; a <= n; a++) { v = rv[i, a]; b = a - 1; while (b >= 1 && rv[i, b] > v) { rv[i, b + 1] = rv[i, b]; b-- } rv[i, b + 1] = v }
              q = n ? rv[i, int(0.99 * (n - 1) + 1.5)] : 0
              printf "%s,%s,%s,%s,%s,%s,%d,%d,%.4f,%s,%d,%d,%d,%.1f\n", L, REP, pid[i], pk[i], ps[i], pe[i], w[i], comp[i],
                     w[i] ? cpu[i] / w[i] : 0, nb[i] ? sprintf("%.1f", bud[i] / nb[i]) : "unlimited", unl[i], mp[i], mi[i], q
            } }' "$OUT/studyb_phases.csv" "$t" >> "$PH"
    done
fi

# ---- 3. printed tables
echo "===== Study B (Milestone 3): whole trace, mean over repetitions (min-max) ====="
awk -F, 'NR > 1 {
    k = $2 " " $1; if (!(k in n)) { ord[++m] = k } n[k]++
    for (j = 0; j < 4; j++) { c = (j == 0 ? 13 : j == 1 ? 15 : j == 2 ? 16 : 14); v = $c + 0
      s[k, j] += v; if (n[k] == 1 || v < lo[k, j]) lo[k, j] = v; if (n[k] == 1 || v > hi[k, j]) hi[k, j] = v }
    bad[k] += $7 + $8 + $9; if ($6 != "" && $5 != $6) short[k]++ }
  END {
    printf "%-16s %4s %24s %26s %22s %24s  %s\n", "policy", "reps", "latency p99 us", "response p99 us", "CPU us/read", "response p50 us", "check"
    for (i = 1; i <= m; i++) { k = ord[i]
      printf "%-16s %4d", k, n[k]
      for (j = 0; j < 4; j++) printf " %10.1f (%.1f-%.1f)", s[k, j] / n[k], lo[k, j], hi[k, j]
      printf "  %s\n", (bad[k] || short[k]) ? "** PROBLEM: errors or missing reads **" : "ok" } }' <(head -1 "$R"; tail -n +2 "$R" | sort -t, -k2,2n -k1,1 -k3,3n)

if [ -f "$PH" ]; then
    echo
    echo "===== Study B (Milestone 3): by phase kind, mean over phases and repetitions ====="
    awk -F, 'NR > 1 { k = $1 "|" $4; if (!(k in n)) ord[++m] = k; n[k]++
        cpu[k] += $9; if ($10 != "unlimited") { b[k] += $10; nb[k]++ }; mp[k] += $12; q[k] += $14 }
      END { printf "%-12s %-7s %14s %16s %16s %24s\n", "policy", "phase", "mean CPU util", "mean budget us", "mean max pending", "window resp p99 us (p99)"
        for (i = 1; i <= m; i++) { k = ord[i]; split(k, a, "|")
          printf "%-12s %-7s %14.3f %16s %16.1f %24.1f\n", a[1], a[2], cpu[k] / n[k], nb[k] ? sprintf("%.1f", b[k] / nb[k]) : "unlimited",
                 mp[k] / n[k], q[k] / n[k] } }' <(head -1 "$PH"; tail -n +2 "$PH" | sort -t, -k1,1 -k4,4r)
fi

echo
awk -F, 'NR > 1 && $1 == "adaptive" { printf "adaptive rep %s: %s budget changes, final level %s, %s blocked spins, %s intervals over allowance (max overshoot %s us), %s probes (%s hits)\n",
         $3, $17, $18, $22, $23, $24, $25, $26 }' "$R"
echo
echo "files: studyb_results.csv, studyb_phases_by_run.csv, runs/timeline_*.csv, runs/adapt_log_*.csv, runs/acct_log_*.csv"
