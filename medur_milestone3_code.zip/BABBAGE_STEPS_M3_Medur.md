# Milestone 3 on Babbage, Medur (tasks 3.2, 3.3, 3.6)

Keep `~/project_m2` as it is. We make a new folder `~/project_m3`.
Never run `make clean` without reason. (In this version it no longer deletes loads.conf / calibration.conf, but keep copies anyway.)

## Step 1. Copy the zip to Babbage (on your laptop)
Use the same way you used for Milestone 2, for example:

    scp medur_milestone3.zip ma672s@babbage:~/

## Step 2. Unpack and bring the Milestone 2 configs and trace (on Babbage)

    cd ~
    rm -rf ~/project_m3 ~/medur_m3
    unzip -q ~/medur_milestone3.zip -d ~
    mv ~/medur_m3 ~/project_m3
    cd ~/project_m3
    cp ~/project_m2/loads.conf ~/project_m2/calibration.conf .
    mkdir -p traces
    cp ~/project_m2/traces/studyb_trace.csv ~/project_m2/traces/studyb_trace.info ~/project_m2/traces/studyb_phases.csv traces/
    chmod +x *.sh tests/*.sh
    cat loads.conf calibration.conf
    sha256sum traces/studyb_trace.csv

Check: spins are 115 / 135 / 145, and the checksum starts with `54224725cee5`.
(If the trace is missing in ~/project_m2, run `sh make_studyb_trace.sh`; it makes the same file.)

## Step 3. Build and run all tests

    make LIBURING=$HOME/liburing-inst
    mkdir -p $HOME/ssd_test
    TESTDIR=$HOME/ssd_test/selftest_m3 make test LIBURING=$HOME/liburing-inst 2>&1 | tee test_m3_output.txt
    grep -E "PASSED|passed|FAIL" test_m3_output.txt

You should see, with no FAIL lines:
`ALL TESTS PASSED`, `HARNESS TESTS PASSED`, `MILESTONE 2 TESTS PASSED`, `LIFECYCLE TESTS PASSED`,
`24 passed, 0 failed`, `MILESTONE 3 TESTS PASSED`, `36 passed, 0 failed`, `MEDUR MILESTONE 3 TESTS PASSED`.

## Step 4. Check that CPU 4 is still quiet (same as Milestone 2)

    awk '/^cpu[0-9]/{print $1,$2+$3+$4,$5+$6}' /proc/stat > /tmp/s1; sleep 5; awk '/^cpu[0-9]/{print $1,$2+$3+$4,$5+$6}' /proc/stat > /tmp/s2
    paste /tmp/s1 /tmp/s2 | awk '{b=$5-$2; i=$6-$3; printf "%-6s busy %5.1f%%\n", $1, 100*b/(b+i)}' | grep -w cpu4

If cpu4 is busy (more than about 5%), pick another quiet core and use it below instead of 4. Write down which one.

## Step 5. Run Study B (about 6 to 7 minutes)
`nohup` keeps it running if your SSH connection drops.

    cd ~/project_m3
    nohup env DATADIR=$HOME/ssd_test CPUS=4 ./run_studyb_m3.sh > studyb_m3_console.txt 2>&1 &
    tail -f studyb_m3_console.txt

Press Ctrl-C to stop watching (the run keeps going). It is finished when the last lines say
`Study B done, all runs ok` and `Next: ./package_m3_medur.sh ...`.

What it does: 3 repetitions. Each repetition = a 3 s warm-up (thrown away), then wait, poll, spin115, spin135,
spin145 and adaptive on the identical trace, in a rotated order. Every read is checked.

## Step 6. Look at the results

    R=$(ls -d results/m3_studyb_* | tail -1); echo $R
    cat $R/studyb_summary.txt

Check: every policy row ends with `ok`, and there are 3 reps per row.

## Step 7. Package

    ./package_m3_medur.sh
    ls -lh upload_m3

You get `medur_milestone3_code.zip`, `milestone3_medur_summary.tgz`, `milestone3_medur_raw.tar.xz.part00, 01, ...`
and `SHA256SUMS.txt`. Every file is under 25 MB.

## Step 8. Upload to a new branch `medur-milestone3`

**Option A: GitHub web page (easiest)**
1. On your laptop: `scp -r ma672s@babbage:~/project_m3/upload_m3 .`
2. Open https://github.com/aungshu30/Project01-CSC720
3. Click the branch menu (says `main`), type `medur-milestone3`, click **Create branch medur-milestone3 from main**.
4. Make sure the branch menu now shows `medur-milestone3`. Click **Add file > Upload files**.
5. Drag in every file from `upload_m3`. Commit message: `Milestone 3 (Medur): tasks 3.2, 3.3, 3.6 and Study B results`. Click **Commit changes**.

**Option B: git on Babbage** (needs a GitHub personal access token as the password)

    cd ~
    git clone https://github.com/aungshu30/Project01-CSC720.git p01_m3
    cd p01_m3
    git checkout -b medur-milestone3
    cp ~/project_m3/upload_m3/* .
    git add .
    git commit -m "Milestone 3 (Medur): tasks 3.2, 3.3, 3.6 and Study B results"
    git push -u origin medur-milestone3

## If something goes wrong
* `run_bench not built`: run Step 3 again.
* `trace checksum ... is not the Milestone 2 Study B trace`: you copied a different trace. Copy it again from ~/project_m2/traces.
* A run says `** run failed`: open `results/m3_studyb_*/runs/summary_<name>_rep<n>.txt` and send me the end of it.
* Disk full: `df -h $HOME`. The raw files are about 25 MB per run (450 MB total). `SAVE_RAW=0` in Step 5 skips them.
