#!/bin/bash
# run_studya.sh - Milestone 3, task 3.5 (Pasha): Study A with policies 1 to 4.
#
#   DATADIR=$HOME/ssd_test CPUS=4 ./run_studya.sh [loads.conf] [calibration.conf]
#
# Needs loads.conf (from ./capacity) and calibration.conf (from ./calibrate), the Milestone 2 outputs.
# Defaults: duration 10 s, 3 repeats, 1 GB test file. Output goes to results/m3_studya_<time>/.
set -e
export LD_LIBRARY_PATH=$HOME/.local/lib:$LD_LIBRARY_PATH
LOADS=${1:-loads.conf}; CALIB=${2:-calibration.conf}
DATADIR=${DATADIR:-$HOME/ssd_test}; CPUS=${CPUS:-}
DUR=${DUR:-10}; REPS=${REPS:-3}; SIZE_MB=${SIZE_MB:-1024}
[ -f "$LOADS" ] || { echo "missing $LOADS (run ./capacity first)"; exit 2; }
[ -f "$CALIB" ] || { echo "missing $CALIB (run ./calibrate first)"; exit 2; }
make -s all
mkdir -p "$DATADIR"
[ -f "$DATADIR/test.bin" ] || ./mkfile "$DATADIR/test.bin" "$SIZE_MB"
OUT=results/m3_studya_$(date +%Y%m%d_%H%M%S); mkdir -p "$OUT"
cp "$LOADS" "$CALIB" "$OUT"/
[ -x ./record_env.sh ] && ./record_env.sh > "$OUT/environment.txt" 2>&1 || uname -a > "$OUT/environment.txt"
PIN=""; [ -n "$CPUS" ] && PIN="taskset -c $CPUS"
echo "Study A: policies 1-4, light and moderate, $REPS repeats of $DUR s  (cpu set: ${CPUS:-any})"
$PIN ./studya --file "$DATADIR/test.bin" --loads "$LOADS" --calib "$CALIB" --duration "$DUR" --reps "$REPS" \
    --outdir "$OUT" | tee "$OUT/studya_summary.txt"
echo; echo "Saved in $OUT/ (study_a_results.csv, adapt_log_*.csv, studya_summary.txt, configs)"
