#!/bin/sh
# Milestone 3 end-to-end checks for Medur's parts, with the real harness and io_uring:
#   3.2  the CPU allowance stops new spins (blocked spins appear, overshoot stays within one spin budget)
#   3.3  a zero budget probes, and probing can be turned off
#   3.6  the Study B runner works end to end on a small trace (all policies, reps, warm-up, tables)
# Run from the project folder:  sh tests/test_m3_medur.sh     (DIRECT=0 if the folder has no O_DIRECT support)
set -e
D=${TESTDIR:-./tmp_test_m3_medur}; mkdir -p "$D"
DIRECT=${DIRECT:-1}
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok:   $1"; else echo "FAIL: $1 (got '$2', wanted '$3')"; fail=1; fi; }
yes_if() { if eval "$1"; then echo yes; else echo no; fi; }
get() { echo "$1" | awk -F': *' -v k="$2" '$1 ~ k {print $2}' | head -1 | awk '{print $1}'; }

./mkfile "$D/test.bin" 64 >/dev/null
./trace_gen --mode steady --rate 6000 --duration 1 --seed 5 --file-size 67108864 --out "$D/t.csv" >/dev/null
N=$(($(wc -l < "$D/t.csv") - 1))
printf 'spin_short_us=100\nspin_mid_us=120\nspin_long_us=140\n' > "$D/calib.conf"
RB="./run_bench --file $D/test.bin --trace $D/t.csv --direct $DIRECT --depth 8 --policy adaptive --calib $D/calib.conf"

# 3.2: default allowance, per-interval log
out=$($RB --acct_log "$D/acct.csv")
check "3.2 adaptive completes all reads"                "$(get "$out" '^requests')" "$N"
check "3.2 no errors / wrong data"                      "$(get "$out" '^errors')/$(get "$out" '^verify failures')" "0/0"
check "3.2 per-interval log has the agreed header" "$(head -1 "$D/acct.csv" | cut -d, -f1-6)" "interval,start_s,level,budget_ns,allowance_ns,spin_ns"
check "3.2 about one row per 10 ms interval (90-110 rows for 1 s)" \
      "$(yes_if "[ $(($(wc -l < "$D/acct.csv") - 1)) -ge 90 ] && [ $(($(wc -l < "$D/acct.csv") - 1)) -le 110 ]")" "yes"
check "3.2 interval starts are on a fixed 10 ms grid" \
      "$(awk -F, 'NR>1 { d = $2 - ($1 * 0.01); if (d < 0) d = -d; if (d > 1e-6) bad++ } END { print bad + 0 }' "$D/acct.csv")" "0"
# overshoot can only come from one spin that started before the allowance ran out (140 us), allow scheduling noise
check "3.2 overshoot within one spin budget in >= 99% of intervals" \
      "$(awk -F, 'NR>1 { n++; if ($14 > 140000 + 50000) bad++ } END { print (bad <= n * 0.01) ? "yes" : "no" }' "$D/acct.csv")" "yes"

# 3.2: a small allowance (3% = 300 us per 10 ms) must block spins, and the spin time must stay near it
out=$($RB --allowance_pct 3 --acct_log "$D/acct3.csv")
check "3.2 small allowance: completes all reads"        "$(get "$out" '^requests')" "$N"
check "3.2 small allowance: spins are blocked"          "$(awk -F, 'NR>1 { b += $13 } END { print (b > 0) ? "yes" : "no" }' "$D/acct3.csv")" "yes"
check "3.2 small allowance: no interval far above it (<= 300 + 140 us + noise)" \
      "$(awk -F, 'NR>1 { n++; if ($6 > 300000 + 140000 + 50000) bad++ } END { print (bad <= n * 0.01) ? "yes" : "no" }' "$D/acct3.csv")" "yes"

# 3.2 clip: shortened spins, no overshoot
$RB --allowance_pct 3 --allowance_clip 1 --acct_log "$D/acctc.csv" >/dev/null
check "3.2 clip: overshoot only from timer noise (<= 50 us)" \
      "$(awk -F, 'NR>1 { n++; if ($14 > 50000) bad++ } END { print (bad <= n * 0.01) ? "yes" : "no" }' "$D/acctc.csv")" "yes"

# 3.2: zero allowance never spins and never probes
out=$($RB --allowance_pct 0 --acct_log "$D/acct0.csv")
check "3.2 zero allowance: completes all reads"         "$(get "$out" '^requests')" "$N"
check "3.2 zero allowance: no spin time, no probes"     "$(awk -F, 'NR>1 { s += $6 + $11 } END { print s + 0 }' "$D/acct0.csv")" "0"

# 3.3: starting at zero with probing every interval, probes happen and are bounded
out=$($RB --start_level 0 --probe_every 1 --probe_backoff 1 --acct_log "$D/acctp.csv")
check "3.3 zero budget: probes are done"                "$(awk -F, 'NR>1 { p += $11 } END { print (p > 0) ? "yes" : "no" }' "$D/acctp.csv")" "yes"
check "3.3 at most 8 probes per interval"               "$(awk -F, 'NR>1 && $11 > 8 { b++ } END { print b + 0 }' "$D/acctp.csv")" "0"
check "3.3 summary line shows probes"                   "$(echo "$out" | grep -c '^probes ')" "1"
out=$($RB --start_level 0 --probe_every 0 --acct_log "$D/acctn.csv")
check "3.3 probe_every 0: no probes, stays at level 0"  "$(awk -F, 'NR>1 { p += $11 } END { print p + 0 }' "$D/acctn.csv")/$(echo "$out" | grep -c 'final level 0')" "0/1"
set +e; $RB --probe_level 0 >/dev/null 2>&1; rc=$?; set -e
check "3.3 bad probe_level is rejected"                 "$([ $rc -ne 0 ] && echo yes || echo no)" "yes"

# 3.6: the Study B runner, end to end on a tiny 3-phase trace (2 reps, 0.2 s warm-up)
mkdir -p "$D/tr"
./trace_gen --mode studyb --seed 77 --file-size 67108864 --sparse-rate 2000 --burst-rate 8000 \
    --sparse-secs 0.3 --burst-secs 0.2 --gap-secs 0.2 --bursts 1 \
    --out "$D/tr/studyb_trace.csv" --phases-out "$D/tr/studyb_phases.csv" >/dev/null
mkdir -p "$D/data"; cp "$D/test.bin" "$D/data/testfile.bin"
set +e
DATADIR="$D/data" SIZE_MB=64 TRACE="$D/tr/studyb_trace.csv" CALIB="$D/calib.conf" REPS=2 WARMUP_S=0.2 DEPTH=8 \
    DIRECT=$DIRECT EXPECT_SHA=skip SAVE_RAW=0 OUTROOT="$D/res" ./run_studyb_m3.sh > "$D/sb.txt" 2>&1; rc=$?
set -e
R=$(ls -d "$D"/res/m3_studyb_* 2>/dev/null | tail -1)
check "3.6 runner exits cleanly"                        "$rc" "0"
check "3.6 6 variants x 2 reps = 12 result rows"        "$(($(wc -l < "$R/studyb_results.csv") - 1))" "12"
check "3.6 no errors / wrong data / missing reads" \
      "$(awk -F, 'NR>1 { e += $7 + $8 + $9; if ($5 != $6) m++ } END { print e + m + 0 }' "$R/studyb_results.csv")" "0"
check "3.6 12 timelines saved"                          "$(ls "$R"/runs/timeline_*.csv | wc -l)" "12"
check "3.6 adaptive logs saved (2 budget + 2 interval)" "$(ls "$R"/runs/adapt_log_*.csv "$R"/runs/acct_log_*.csv | wc -l)" "4"
check "3.6 warm-up before each rep"                     "$(ls "$R"/warmup/warmup_rep*.txt | wc -l)" "2"
check "3.6 order rotates between reps" \
      "$(awk -F, 'NR>1 && $4 == 1 { f[$3] = $1 } END { print (f[1] != f[2]) ? "yes" : "no" }' "$R/run_order.csv")" "yes"
check "3.6 phase table has 6 x 2 x 3 rows"              "$(($(wc -l < "$R/studyb_phases_by_run.csv") - 1))" "36"

[ $fail -eq 0 ] && echo "MEDUR MILESTONE 3 TESTS PASSED" || { echo "SOME TESTS FAILED"; exit 1; }
