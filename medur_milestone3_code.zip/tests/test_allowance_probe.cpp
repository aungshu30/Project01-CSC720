// test_allowance_probe.cpp - unit tests for tasks 3.2 (fixed interval + CPU allowance) and
// 3.3 (bounded probes at a zero budget), Medur. No SSD and no io_uring: a fake clock drives the engine.
//   make test_allowance_probe && ./test_allowance_probe
#include <cstdio>
#include <string>
#include <vector>

#include "adaptive_engine.h"

static int g_fail = 0, g_pass = 0;
#define CHECK(name, cond)                                                            \
    do {                                                                             \
        if (cond) { g_pass++; std::printf("ok:   %s\n", name); }                    \
        else { g_fail++; std::printf("FAIL: %s  (line %d)\n", name, __LINE__); }    \
    } while (0)

static const uint64_t US = 1000, MS = 1000000;
static const uint64_t T0 = 5 * 1000 * MS;  // arbitrary absolute start time

// Defaults used everywhere: 10 ms interval, 25% allowance (2.5 ms), levels {0,115,135,145} us.
static AdaptiveConfig base_cfg() { return AdaptiveConfig(); }

// One spin through the engine. The completion would arrive `lat` ns after now.
// Returns the time after the spin (or now if no spin was done).
struct Spin { SpinPlan p; uint64_t end; bool hit; };
static Spin spin_once(AdaptiveEngine& e, uint64_t now, uint64_t lat, int64_t timeout = -1) {
    Spin s{e.plan(now, timeout), now, false};
    if (s.p.budget_ns > 0) {
        s.hit = static_cast<int64_t>(lat) <= s.p.budget_ns;
        const uint64_t used = s.hit ? lat : static_cast<uint64_t>(s.p.budget_ns);
        s.end = now + used;
        e.done(s.p, now, s.end, used, s.hit);
    }
    return s;
}

// A closed loop of reads, one at a time: spin (if planned), else sleep until the read completes.
// Simulates `dur` ns starting at `t`, read latency given by lat_of(t). Returns the end time.
template <class F>
static uint64_t run_reads(AdaptiveEngine& e, uint64_t t, uint64_t dur, F lat_of) {
    const uint64_t end = t + dur;
    while (t < end) {
        const uint64_t lat = lat_of(t);
        Spin s = spin_once(e, t, lat);
        t = s.hit ? s.end : t + (lat > s.end - t ? lat : s.end - t);  // wait for the completion if missed
        t += 2 * US;                                                    // tiny gap, then the next read
    }
    e.tick(t);
    return t;
}

int main() {
    // ------------------------------------------------------------------ 3.2: CPU allowance
    {
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(base_cfg(), AcctConfig(), &ctl);
        uint64_t t = T0;
        int started = 0, blocked = 0;
        for (int i = 0; i < 40; i++) {  // spins that always miss, back to back, all inside interval 0
            Spin s = spin_once(e, t, 1 * MS);
            if (s.p.budget_ns > 0) started++;
            if (s.p.blocked) blocked++;
            t = s.end + 1 * US;
        }
        CHECK("3.2 allowance stops NEW spins once used up (22 x 115 us started, rest blocked)", started == 22 && blocked == 18);
        CHECK("3.2 blocked spins are counted in the interval", e.acct().current().blocked == 18);
        CHECK("3.2 spin time charged = 22 x 115 us", e.acct().current().spin_ns == 22 * 115 * US);
        e.tick(T0 + 10 * MS);
        const IntervalStats& s0 = e.acct().log().at(0);
        CHECK("3.2 overshoot is reported (2530 - 2500 = 30 us)", s0.overshoot_ns == 30 * US);
        CHECK("3.2 overshoot is at most one spin budget", s0.overshoot_ns <= 115 * US);
        CHECK("3.2 requested allowance is logged (2.5 ms)", s0.allowance_ns == 2500 * (int64_t)US);
        CHECK("3.2 measured spin CPU is logged", s0.spin_cpu_ns == 22 * 115 * US);
        CHECK("3.2 controller saw the allowance was used and lowered the budget", ctl.level() == 0 &&
              std::string(ctl.log().at(0).reason) == "allowance exceeded");
    }
    {   // clip mode: the last spin is shortened to what is left, so there is no overshoot
        AdaptiveController ctl;
        AdaptiveEngine e;
        AcctConfig mc;
        mc.clip = true;
        e.reset(base_cfg(), mc, &ctl);
        uint64_t t = T0;
        int64_t last = 0;
        for (int i = 0; i < 30; i++) {
            Spin s = spin_once(e, t, 1 * MS);
            if (s.p.budget_ns > 0) last = s.p.budget_ns;
            t = s.end + 1 * US;
        }
        CHECK("3.2 clip: last spin shortened to the 85 us left", last == 85 * (int64_t)US);
        CHECK("3.2 clip: spin time equals the allowance exactly", e.acct().current().spin_ns == 2500 * US);
        CHECK("3.2 clip: a shortened miss is counted as cut, not as a miss", e.acct().current().cut == 1 &&
              e.acct().current().spins == 21);
        e.tick(T0 + 10 * MS);
        CHECK("3.2 clip: no overshoot", e.acct().log().at(0).overshoot_ns == 0);
    }
    {   // the allowance is per interval: it starts again at the next interval
        CpuAllowance a;
        a.reset(10 * MS, 2500 * US, false);
        a.advance(T0, [](const IntervalStats&, IntervalStats&) {});
        a.charge(T0, T0 + 2600 * US, 0);
        const bool before = a.can_start();
        a.advance(T0 + 10 * MS, [](const IntervalStats&, IntervalStats&) {});
        CHECK("3.2 a used-up interval allows no spin, the next interval allows spins again", !before && a.can_start());
    }
    {   // fixed grid: a long sleep closes every skipped interval and does not shift the grid
        CpuAllowance a;
        a.reset(10 * MS, 2500 * US, false);
        a.advance(T0, [](const IntervalStats&, IntervalStats&) {});
        std::vector<uint64_t> closed;
        size_t n = a.advance(T0 + 35 * MS, [&](const IntervalStats& c, IntervalStats&) { closed.push_back(c.index); });
        CHECK("3.2 fixed interval: 35 ms of sleep closes intervals 0, 1, 2", n == 3 && closed == std::vector<uint64_t>({0, 1, 2}));
        CHECK("3.2 fixed interval: current interval is #3 starting at exactly 30 ms",
              a.current().index == 3 && a.current().start_ns == 30 * MS);
    }
    {   // spill: a spin that starts near the end of an interval is charged there, the part past the end is reported
        CpuAllowance a;
        a.reset(10 * MS, 2500 * US, false);
        a.advance(T0, [](const IntervalStats&, IntervalStats&) {});
        a.charge(T0 + 9950 * US, T0 + 10095 * US, 0);
        CHECK("3.2 spill past the interval end is reported (95 us)", a.current().spill_ns == 95 * US &&
              a.current().spin_ns == 145 * US);
    }
    {   // a spin cut short by the next arrival says nothing about the hit rate
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(base_cfg(), AcctConfig(), &ctl);
        Spin s = spin_once(e, T0, 1 * MS, 20 * US);
        CHECK("3.2 next arrival in 20 us: spin limited to 20 us", s.p.budget_ns == 20 * (int64_t)US);
        CHECK("3.2 ... and that miss is counted as cut, not as a miss",
              e.acct().current().cut == 1 && e.acct().current().spins == 0 && e.acct().current().spin_ns == 20 * US);
        Spin z = spin_once(e, T0 + 1 * MS, 1 * MS, 0);
        CHECK("3.2 next arrival due now: no spin, and not counted as blocked", z.p.budget_ns == 0 && !z.p.blocked);
    }
    {   // zero allowance: never spins, never probes, but still returns (the policy then sleeps = progress)
        AdaptiveConfig c = base_cfg();
        c.allowance = 0;
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(c, AcctConfig(), &ctl);
        uint64_t end = run_reads(e, T0, 300 * MS, [](uint64_t) { return 50 * US; });
        e.finish();
        const auto tot = e.acct().totals();
        CHECK("3.2 zero allowance: no spin time at all, ever", tot.spin_ns == 0 && tot.spins == 0 && tot.probes == 0);
        CHECK("3.2 zero allowance: reads still complete (time moved on)", end > T0 + 300 * MS);
        CHECK("3.2 zero allowance: ends at level 0", ctl.level() == 0);
    }

    // ------------------------------------------------------------------ 3.3: bounded probes
    {   // no probes while the level is above zero
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(base_cfg(), AcctConfig(), &ctl);
        e.tick(T0);
        CHECK("3.3 no probes while the budget is above zero", !e.probes().available());
    }
    {   // at level 0: probes come occasionally, are bounded in number and length, and back off when they fail
        AdaptiveConfig c = base_cfg();
        c.start_level = 0;
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(c, AcctConfig(), &ctl);
        std::vector<uint64_t> probing;  // intervals with probes
        bool all_mid = true, bounded = true;
        for (uint64_t k = 0; k < 60; k++) {
            uint64_t t = T0 + k * 10 * MS + 1 * US;
            int n = 0;
            for (int i = 0; i < 20; i++) {  // 20 chances per interval; completion never comes in time
                Spin s = spin_once(e, t, 1 * MS);
                if (s.p.budget_ns > 0) {
                    n++;
                    if (!s.p.probe || s.p.budget_ns != 135 * (int64_t)US) all_mid = false;
                }
                t = s.end + 1 * US;
            }
            if (n > 0) probing.push_back(k);
            if (n > 8) bounded = false;
        }
        e.tick(T0 + 61 * 10 * MS);
        uint64_t max_probe_ns = 0;
        for (const auto& s : e.acct().log())
            if (s.spin_ns > max_probe_ns) max_probe_ns = s.spin_ns;
        CHECK("3.3 first probing interval comes within probe_every (5) intervals", !probing.empty() && probing[0] < 5);
        CHECK("3.3 at most probes_per_window (8) probes in one interval", bounded);
        CHECK("3.3 each probe spins for the mid budget (135 us)", all_mid);
        CHECK("3.3 probe CPU per interval is bounded (<= 8 x 135 us)", max_probe_ns <= 8 * 135 * US);
        std::vector<uint64_t> gaps;
        for (size_t i = 1; i < probing.size(); i++) gaps.push_back(probing[i] - probing[i - 1]);
        CHECK("3.3 failed probes back off: gaps 10, 20, 20 intervals (max 4 x 5)",
              gaps.size() >= 3 && gaps[0] == 10 && gaps[1] == 20 && gaps[2] == 20);
        CHECK("3.3 failed probes keep the budget at zero", ctl.level() == 0);
    }
    {   // back-off off: fixed spacing
        AdaptiveConfig c = base_cfg();
        c.start_level = 0;
        AcctConfig mc;
        mc.probe_backoff = 1;
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(c, mc, &ctl);
        std::vector<uint64_t> probing;
        for (uint64_t k = 0; k < 20; k++) {
            Spin s = spin_once(e, T0 + k * 10 * MS + 1 * US, 1 * MS);
            if (s.p.probe) probing.push_back(k);
        }
        CHECK("3.3 probe_backoff=1: probing every 5 intervals", probing.size() >= 3 && probing[1] - probing[0] == 5 &&
              probing[2] - probing[1] == 5);
    }
    {   // probes are charged to the same allowance: tiny allowance -> at most one probe per interval
        AdaptiveConfig c = base_cfg();
        c.start_level = 0;
        c.allowance = 0.01;  // 100 us per 10 ms
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(c, AcctConfig(), &ctl);
        int max_n = 0;
        for (uint64_t k = 0; k < 12; k++) {
            uint64_t t = T0 + k * 10 * MS + 1 * US;
            int n = 0;
            for (int i = 0; i < 10; i++) {
                Spin s = spin_once(e, t, 1 * MS);
                if (s.p.budget_ns > 0) n++;
                t = s.end + 1 * US;
            }
            if (n > max_n) max_n = n;
        }
        CHECK("3.3 probes respect the CPU allowance (1 probe fits in 100 us)", max_n == 1);
    }
    {   // THE main 3.3 test: the budget falls to zero under slow completions, then recovers through probes
        // once the traffic changes so that spinning pays off again.
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(base_cfg(), AcctConfig(), &ctl);
        const uint64_t change = T0 + 500 * MS;
        auto lat = [&](uint64_t t) { return t < change ? 300 * US : 40 * US; };  // slow, then fast
        run_reads(e, T0, 500 * MS, lat);
        const int level_before = ctl.level();
        uint64_t recovered_at = 0;
        uint64_t t = change;
        while (t < change + 600 * MS) {
            t = run_reads(e, t, 1 * MS, lat);
            if (ctl.level() > 0) { recovered_at = t; break; }
        }
        CHECK("3.3 slow completions: budget drops to zero", level_before == 0);
        CHECK("3.3 zero budget recovers through probes after the traffic changes", recovered_at != 0);
        bool reason = false;
        for (const auto& a : ctl.log())
            if (a.from == 0 && a.to == 1 && std::string(a.reason) == "probe hit" && a.t_ns >= 500 * MS) reason = true;
        CHECK("3.3 ... the log says it was a probe hit", reason);
        CHECK("3.3 ... within the longest probe gap (20 intervals = 200 ms) plus one interval",
              recovered_at != 0 && recovered_at - change <= 210 * MS);
    }
    {   // control: without probes the zero budget never recovers
        AdaptiveConfig c = base_cfg();
        c.probe_every = 0;
        AdaptiveController ctl;
        AdaptiveEngine e;
        e.reset(c, AcctConfig(), &ctl);
        const uint64_t change = T0 + 500 * MS;
        auto lat = [&](uint64_t t) { return t < change ? 300 * US : 40 * US; };
        run_reads(e, T0, 1000 * MS, lat);
        CHECK("3.3 control: with probes turned off the zero budget stays at zero", ctl.level() == 0);
    }

    std::printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
