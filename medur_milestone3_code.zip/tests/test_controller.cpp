// test_controller.cpp - unit tests for the adaptive controller rule (task 3.1). No SSD and no io_uring needed.
//   make test_controller && ./test_controller
#include <cstdio>
#include <cstdlib>
#include <string>

#include "adaptive_controller.h"

static int g_fail = 0, g_pass = 0;
#define CHECK(name, cond)                                  \
    do {                                                   \
        if (cond) { g_pass++; std::printf("ok:   %s\n", name); } \
        else { g_fail++; std::printf("FAIL: %s  (line %d)\n", name, __LINE__); } \
    } while (0)

// helpers: a window with a given hit rate (out of 100 spins) and spin time as a share of the allowance
static WindowStats win(int hits_of_100, double spin_share_of_allowance, const AdaptiveConfig& c) {
    WindowStats s;
    s.spins = 100;
    s.hits = static_cast<uint64_t>(hits_of_100);
    s.spin_ns = static_cast<uint64_t>(spin_share_of_allowance * c.allowance * static_cast<double>(c.window_ns));
    return s;
}

int main() {
    AdaptiveConfig c;  // defaults: levels {0,115,135,145} us, allowance 25%, up_patience 3, cooldown 3

    { AdaptiveController k(c);
      CHECK("starts at level 1 (shortest non-zero budget)", k.level() == 1 && k.budget_ns() == 115000); }

    { AdaptiveController k(c);
      k.update(win(95, 1.2, c));
      CHECK("allowance exceeded lowers the budget", k.level() == 0);
      CHECK("... and logs the reason", k.log().size() == 1 && std::string(k.log()[0].reason) == "allowance exceeded"); }

    { AdaptiveController k(c);
      k.update(win(10, 0.3, c));
      CHECK("low hit rate lowers the budget", k.level() == 0 && std::string(k.log()[0].reason) == "low hit rate"); }

    { AdaptiveController k(c);
      k.update(win(95, 0.3, c)); k.update(win(95, 0.3, c));
      CHECK("productive windows do not raise before patience is met", k.level() == 1);
      k.update(win(95, 0.3, c));
      CHECK("third productive window raises ONE level", k.level() == 2 && std::string(k.log()[0].reason) == "productive"); }

    { AdaptiveController k(c);
      for (int i = 0; i < 20; i++) k.update(win(95, 0.3, c));
      CHECK("never goes above level 3", k.level() == 3 && k.budget_ns() == 145000); }

    { AdaptiveController k(c);
      for (int i = 0; i < 20; i++) k.update(win(95, 0.9, c));  // good hits but using most of the allowance
      CHECK("no raising when spin time is close to the allowance (no headroom)", k.level() == 1 && k.log().empty()); }

    { AdaptiveController k(c);
      k.update(win(95, 0.3, c)); k.update(win(95, 0.3, c)); k.update(win(95, 0.3, c));  // -> level 2
      k.update(win(10, 0.3, c));                                                         // -> level 1, cooldown starts
      CHECK("lowering after a raise", k.level() == 1);
      k.update(win(95, 0.3, c)); k.update(win(95, 0.3, c)); k.update(win(95, 0.3, c));
      CHECK("cooldown blocks raising right after a lowering", k.level() == 1);
      k.update(win(95, 0.3, c));
      CHECK("raising works again once the cooldown has passed", k.level() == 2); }

    { AdaptiveController k(c);
      WindowStats few; few.spins = 5; few.hits = 0; few.spin_ns = 1000;
      k.update(few);
      CHECK("too few spins = not enough evidence, budget unchanged", k.level() == 1 && k.log().empty()); }

    { AdaptiveController k(c);
      for (int i = 0; i < 30; i++) k.update(win(0, 2.0, c));
      CHECK("never goes below level 0", k.level() == 0 && k.budget_ns() == 0); }

    { AdaptiveController k(c);
      k.update(win(0, 0.3, c));  // -> 0
      WindowStats p; p.probes = 8; p.probe_hits = 7;
      k.update(p);
      CHECK("zero budget recovers to level 1 when the probes hit", k.level() == 1 && std::string(k.log().back().reason) == "probe hit"); }

    { AdaptiveController k(c);
      k.update(win(0, 0.3, c));
      WindowStats p; p.probes = 8; p.probe_hits = 2;
      k.update(p);
      CHECK("zero budget stays at zero when the probes miss", k.level() == 0);
      WindowStats q; q.probes = 2; q.probe_hits = 2;
      k.update(q);
      CHECK("... and when there are too few probes", k.level() == 0);
      WindowStats z = win(100, 0.1, c);  // spin stats at level 0 are ignored
      k.update(z);
      CHECK("spin statistics cannot raise a zero budget (only probes can)", k.level() == 0); }

    { AdaptiveConfig c0 = c; c0.start_level = 3;
      AdaptiveController k(c0);
      CHECK("start_level is respected", k.level() == 3);
      c0.start_level = 9; AdaptiveController k2(c0);
      CHECK("start_level is clamped to 0..3", k2.level() == 3); }

    { AdaptiveController k(c);
      k.update(win(10, 0.3, c), 12345);
      const Adjustment& a = k.log()[0];
      CHECK("log keeps window number, time, levels and the numbers behind the change",
            a.window == 1 && a.t_ns == 12345 && a.from == 1 && a.to == 0 && a.stats.spins == 100 &&
            a.requested_allowance_ns == 2500000);
      CHECK("allowance is 25% of the 10 ms window", k.allowance_ns() == 2500000);
      const std::string path = "tmp_controller_log.csv";
      CHECK("write_log writes a CSV", k.write_log(path));
      FILE* f = std::fopen(path.c_str(), "r"); char buf[512] = {0};
      if (f) { (void)!std::fgets(buf, sizeof buf, f); (void)!std::fgets(buf, sizeof buf, f); std::fclose(f); }
      CHECK("... with the adjustment row", std::string(buf).find("low hit rate") != std::string::npos);
      std::remove(path.c_str()); }

    { // same inputs, same decisions (the study needs repeatable behaviour)
      AdaptiveController a(c), b(c);
      for (int i = 0; i < 50; i++) { WindowStats s = win((i * 37) % 100, 0.1 + (i % 7) * 0.12, c); a.update(s); b.update(s); }
      CHECK("deterministic: same windows give the same level and log", a.level() == b.level() && a.log().size() == b.log().size()); }

    std::printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
