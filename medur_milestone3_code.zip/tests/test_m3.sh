#!/bin/sh
# Milestone 3 checks for policy 4 (adaptive), task 3.1: it finishes every read, writes a budget log,
# respects a zero allowance, and the budgets come from calibration.conf.
set -e
D=${TESTDIR:-./tmp_test_m3}; mkdir -p "$D"
DIRECT=${DIRECT:-1}
fail=0
check() { if [ "$2" = "$3" ]; then echo "ok:   $1"; else echo "FAIL: $1 (got '$2', wanted '$3')"; fail=1; fi; }
get() { echo "$1" | awk -F': *' -v k="$2" '$1 ~ k {print $2}' | head -1 | awk '{print $1}'; }

./mkfile "$D/test.bin" 64 >/dev/null
./trace_gen --mode steady --rate 4000 --duration 1 --seed 5 --file-size 67108864 --out "$D/t.csv" >/dev/null
N=$(($(wc -l < "$D/t.csv") - 1))
printf 'spin_short_us=100\nspin_mid_us=120\nspin_long_us=140\n' > "$D/calib.conf"

out=$(./run_bench --file "$D/test.bin" --trace "$D/t.csv" --direct $DIRECT --depth 8 --policy adaptive --calib "$D/calib.conf" --adapt_log "$D/log.csv")
check "adaptive completes all reads"            "$(get "$out" '^requests')" "$N"
check "adaptive: no errors / wrong data"        "$(get "$out" '^errors')/$(get "$out" '^verify failures')" "0/0"
check "adaptive writes a budget log with header" "$(head -1 "$D/log.csv" | cut -d, -f1-3)" "window,t_ns,from_level"
check "adaptive reports its windows"            "$(echo "$out" | grep -c '^adaptive ')" "1"

# zero allowance: it may never spin, so it must fall to level 0 and still finish every read
out=$(./run_bench --file "$D/test.bin" --trace "$D/t.csv" --direct $DIRECT --depth 8 --policy adaptive --calib "$D/calib.conf" --allowance_pct 0)
check "allowance 0: completes all reads"        "$(get "$out" '^requests')" "$N"
check "allowance 0: ends at level 0"            "$(echo "$out" | grep '^adaptive ' | grep -c 'final level 0')" "1"

# depth 1, every start level
for L in 0 1 2 3; do
  out=$(./run_bench --file "$D/test.bin" --trace "$D/t.csv" --direct $DIRECT --depth 1 --policy adaptive --start_level $L)
  check "start_level $L, depth 1: completes all"  "$(get "$out" '^requests')" "$N"
done

# bad settings are clear errors
set +e
./run_bench --file "$D/test.bin" --trace "$D/t.csv" --policy adaptive --short_us 200 --mid_us 150 >/dev/null 2>&1; rc=$?
set -e
check "non-increasing budgets are rejected"     "$([ $rc -ne 0 ] && echo yes || echo no)" "yes"

# the over-time recorder shows the policy 4 budget
./run_bench --file "$D/test.bin" --trace "$D/t.csv" --direct $DIRECT --depth 8 --policy adaptive --timeline "$D/tl.csv" >/dev/null
check "timeline file written for adaptive"      "$([ -s "$D/tl.csv" ] && echo yes || echo no)" "yes"

# 3.5 Study A runner: policies 1 to 4, short run, every read checked, adaptive logs saved
printf 'depth=8\nlight_rps=1000\nmoderate_rps=4000\n' > "$D/loads.conf"
./studya --file "$D/test.bin" --loads "$D/loads.conf" --calib "$D/calib.conf" --depth 8 --direct $DIRECT --duration 1 --reps 2 --outdir "$D/sa" > "$D/sa.txt"
check "studya exits cleanly"                    "$?" "0"
check "studya: 2 loads x 6 variants x 2 repeats = 24 rows" "$(($(wc -l < "$D/sa/study_a_results.csv") - 1))" "24"
check "studya: no errors anywhere"              "$(awk -F, 'NR>1{e+=$12+$13+$14} END{print e+0}' "$D/sa/study_a_results.csv")" "0"
check "studya: adaptive logs saved (4 runs)"    "$(ls "$D"/sa/adapt_log_*.csv | wc -l)" "4"
check "studya: all 5 policy rows per load"      "$(grep -c '4 adaptive' "$D/sa/study_a_results.csv")" "4"

[ $fail -eq 0 ] && echo "MILESTONE 3 TESTS PASSED" || { echo "SOME TESTS FAILED"; exit 1; }
