# Milestone 3, Pasha: adaptive controller (task 3.1) and Study A (task 3.5)

Built on the merged Milestone 2 code (Medur's tree), so it uses the same harness, `Policy` interface and
over-time recorder. New files:

| File | What it is |
|---|---|
| `src/adaptive_controller.h` | The rule. Pure logic, no io_uring. Takes one window of numbers, returns the next budget level. |
| `src/policy_adaptive.h` | Policy 4. Same I/O path as policy 3 (peek for at most the budget, then sleep), plus window counters. |
| `tests/test_controller.cpp` | 24 unit tests of the rule (no SSD needed). |
| `tests/test_m3.sh` | End-to-end checks of `--policy adaptive` with run_bench. |
| `src/studya.cpp`, `run_studya.sh` | Task 3.5: Study A, policies 1 to 4, light and moderate loads, 3 repeats. |
| `src/adaptive_args.h` | Reads policy 4 settings, shared by run_bench and studya. |
| `src/policies.h`, `src/run_bench.cpp` | `adaptive` added; `--calib`, `--allowance_pct`, `--adapt_log` and the tuning keys below. |

## The rule (levels: 0 = no spin, 1 = short 115 us, 2 = mid 135 us, 3 = long 145 us, from `calibration.conf`)
Once per window (default 10 ms):
1. Spin time used >= CPU allowance (default 25% of the window): go down one level.
2. Hit rate (completion found while spinning) < 40%, with at least 20 spins: go down one level.
3. Hit rate >= 80% for 3 windows in a row and spin time <= 60% of the allowance: try ONE level up.
   Not allowed for 3 windows after a lowering (cooldown), so it cannot flip up and down.
4. At level 0 there is nothing to measure, so occasional bounded probes decide: if >= 70% of at least 3 probes
   hit, go back to level 1.

## Run it
    make LIBURING=$HOME/liburing-inst
    ./run_bench --file $HOME/ssd_test/test.bin --trace steady.csv --policy adaptive \
        --calib calibration.conf --adapt_log adapt_log.csv --timeline timeline.csv
Keys (all optional): `ctl_window_ms` (10), `allowance_pct` (25), `min_spins`, `up_hit`, `down_hit`, `up_patience`,
`cooldown`, `headroom`, `start_level` (1), `probe_every` (5).
`make test` runs everything. On a machine without O_DIRECT support use `DIRECT=0 make test`.

## Joining with the other owners' parts
* Medur 3.2 (allowance accounting) and 3.3 (probes): `policy_adaptive.h` has small stand-ins for both, marked in
  the comments. Fill `WindowStats` (spins, hits, spin_ns, probes, probe_hits) from the real versions; the rule does not change.
* Sirisha 3.4 (logging, controller tests): `AdaptiveController::log()` / `write_log()` already record every change with the
  numbers behind it (requested allowance vs measured spin time). Extend or replace as needed.
* The recorder's budget column follows `g_budget_ns`, which policy 4 updates at every window.

## Task 3.5: Study A (on Babbage, after loads.conf and calibration.conf exist from Milestone 2)
    DATADIR=$HOME/ssd_test CPUS=4 ./run_studya.sh loads.conf calibration.conf
Runs wait (1), poll (2), spin at the three calibrated durations (3) and adaptive (4) on the light and moderate steady
loads, 10 s each, 3 repeats, same trace (seed 1) for every policy, round-robin over repeats, every read checked.
Collects p50, p99, reads per second and CPU time per read. Output in `results/m3_studya_<time>/`:
`study_a_results.csv` (one row per run), `adapt_log_<load>_rep<n>.csv` (every budget change of policy 4),
`studya_summary.txt` (mean and min-max table), plus the config files used.
