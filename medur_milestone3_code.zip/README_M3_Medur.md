# Milestone 3, Medur: CPU allowance (3.2), bounded probes (3.3), Study B (3.6)

Built on Pasha's Milestone 3 tree (his controller, task 3.1, is unchanged). His stand-ins for 3.2 and 3.3
in `policy_adaptive.h` are replaced by the real versions below. Policy 4 is still `pick_policy("adaptive")`.

## New and changed files

| File | What it is |
|---|---|
| `src/cpu_allowance.h` | 3.2. Fixed accounting interval on a grid that never drifts, CPU allowance per interval, no new spin once it is used up, overshoot and spill reported per interval. |
| `src/probe_scheduler.h` | 3.3. Occasional bounded probes at a zero budget, with back-off when probes fail. |
| `src/adaptive_engine.h` | Joins Pasha's rule + allowance + probes. No io_uring, so it is unit tested with a fake clock. |
| `src/policy_adaptive.h` | Policy 4, now a thin I/O wrapper around the engine (same names as before). |
| `tests/test_allowance_probe.cpp` | 36 unit tests for 3.2 and 3.3 (no SSD needed). |
| `tests/test_m3_medur.sh` | End-to-end checks with the real harness, plus a small Study B run. |
| `run_studyb_m3.sh` | 3.6. Study B, policies 1 to 4, 3 repetitions, warm-up before each. |
| `summarize_studyb_m3.sh` | Builds the Study B tables (awk only). Called by the runner. |
| `package_m3_medur.sh` | Packs code and results for GitHub (every file under 25 MB). |
| `src/adaptive_args.h`, `src/run_bench.cpp`, `src/studya.cpp`, `Makefile` | Small additions, marked `M3 Medur`. `make clean` no longer deletes loads.conf and calibration.conf (`make distclean` does). |

## 3.2 How the allowance works
* Intervals are fixed: interval k = [start + k x 10 ms, start + (k+1) x 10 ms).
* Allowance = `allowance_pct` (default 25%) of an interval = 2.5 ms of spinning.
* Each spin or probe is charged to the interval where it started. Once the charged time reaches the
  allowance, no new spin starts; the policy just sleeps until the next interval.
* A spin that started just before the limit can end after it. That extra time (overshoot) is at most
  one spin budget and is reported. `--allowance_clip 1` shortens the last spin instead (no overshoot).
* A spin ended early only because the next read was due, and that missed, is counted as `cut`, not
  as a miss, so it does not lower the hit rate unfairly.
* Thread CPU is measured during each spin (`spin_cpu_ns`), next to the requested allowance.
  This is the hook for Sirisha's 3.4 logging.

## 3.3 How the probes work
* Only at a zero budget. One interval out of every `probe_every` (default 5 = every 50 ms).
* At most `probes_per_window` (8) probes there, each at most the mid budget (`probe_level` 2 = 135 us),
  and probes count against the same allowance. Worst case 1.08 ms of a 10 ms interval.
* If a round fails, the gap doubles up to `probe_every x probe_backoff` (default 4x = 200 ms).
  It resets as soon as the budget is above zero. `--probe_backoff 1` turns this off.
* Pasha's rule 4 reads the results: 70% of at least 3 probes hit, back to level 1.

## Outputs of policy 4
`--acct_log FILE` writes one row per interval:
`interval,start_s,level,budget_ns,allowance_ns,spin_ns,spin_cpu_ns,spins,hits,cut,probes,probe_hits,blocked,overshoot_ns,spill_ns`
`--adapt_log FILE` is Pasha's log of every budget change (its `t_ns` is now time since the run started).
run_bench also prints three lines: `allowance`, `spin accounting`, `probes`.

## Run on Babbage
See `BABBAGE_STEPS_M3_Medur.md`.
