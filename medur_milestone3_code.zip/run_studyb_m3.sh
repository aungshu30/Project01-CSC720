#!/bin/bash
# run_studyb_m3.sh - Milestone 3, task 3.6 (Medur): Study B with policies 1 to 4.
#
# Replays the SAME Study B trace (sparse, burst, sparse; made once in Milestone 2, seed 2002) with:
#   1 wait   2 poll   3 spin at the three calibrated budgets   4 adaptive (Pasha's rule + Medur's allowance and probes)
# for REPS repetitions. Before every repetition a short warm-up run is done and thrown away (Milestone 2 showed
# that the first run can be an outlier). The policy order is rotated in each repetition so no policy is always first.
# Every run saves the over-time CSV (budget, CPU, latency, pending per window). Policy 4 also saves its budget-change
# log and its per-interval allowance log.
#
#   DATADIR=$HOME/ssd_test CPUS=4 ./run_studyb_m3.sh
#
# Optional settings (environment):
#   TRACE=traces/studyb_trace.csv  CALIB=calibration.conf  REPS=3  DEPTH=32  DIRECT=1  WINDOW_MS=10  SIZE_MB=1024
#   WARMUP_S=3        seconds of warm-up before each repetition (0 = none)
#   EXPECT_SHA=...    trace checksum to insist on (default: the Milestone 2 Study B trace). "skip" = do not check
#   SAVE_RAW=1        also save the per-request CSVs (big, about 20 MB per run)
#   ADAPT_ARGS="..."  extra run_bench options for policy 4, e.g. "--allowance_pct 25 --probe_backoff 4"
#   OUTROOT=results   where the results folder is made
set -u

DATADIR=${DATADIR:?set DATADIR to a folder on the local SSD, e.g. DATADIR=\$HOME/ssd_test}
TRACE=${TRACE:-traces/studyb_trace.csv}
CALIB=${CALIB:-calibration.conf}
REPS=${REPS:-3}
DEPTH=${DEPTH:-32}
DIRECT=${DIRECT:-1}
WINDOW_MS=${WINDOW_MS:-10}
SIZE_MB=${SIZE_MB:-1024}
WARMUP_S=${WARMUP_S:-3}
SAVE_RAW=${SAVE_RAW:-1}
ADAPT_ARGS=${ADAPT_ARGS:-}
OUTROOT=${OUTROOT:-results}
CPUS=${CPUS:-}
M2_SHA=54224725cee50c21c5b4216e27f595ac3ef450e114108abf5e4c94f745161ad2
EXPECT_SHA=${EXPECT_SHA:-$M2_SHA}

die() { echo "ERROR: $*"; exit 2; }
conf() { awk -F= -v k="$2" '$1==k {print $2}' "$1"; }

# ---- 1. checks before anything runs
[ -x ./run_bench ] || die "run_bench not built. Run: make LIBURING=\$HOME/liburing-inst"
[ -f "$TRACE" ] || die "missing $TRACE. Copy traces/ from ~/project_m2, or run make_studyb_trace.sh"
[ -f "$CALIB" ] || die "missing $CALIB. Copy it from ~/project_m2"
S1=$(conf "$CALIB" spin_short_us); S2=$(conf "$CALIB" spin_mid_us); S3=$(conf "$CALIB" spin_long_us)
[ -n "$S1" ] && [ -n "$S2" ] && [ -n "$S3" ] || die "$CALIB needs spin_short_us, spin_mid_us, spin_long_us"
SHA0=$(sha256sum "$TRACE" | cut -d' ' -f1)
if [ "$EXPECT_SHA" != "skip" ] && [ "$SHA0" != "$EXPECT_SHA" ]; then
    die "trace checksum $SHA0 is not the Milestone 2 Study B trace ($EXPECT_SHA). Use the same trace, or EXPECT_SHA=skip"
fi
INFO="${TRACE%_trace.csv}_trace.info"; PHASES="${TRACE%_trace.csv}_phases.csv"
NREQ=$(($(wc -l < "$TRACE") - 1))

FILE=$DATADIR/testfile.bin
BYTES=$((SIZE_MB * 1024 * 1024))
if [ -f "$INFO" ]; then
    TFS=$(conf "$INFO" file_size)
    [ -n "$TFS" ] && [ "$TFS" != "$BYTES" ] && die "trace was made for a $TFS byte file, but SIZE_MB=$SIZE_MB gives $BYTES"
fi
mkdir -p "$DATADIR"
if [ ! -f "$FILE" ] || [ "$(stat -c %s "$FILE")" != "$BYTES" ]; then
    echo "making test file $FILE ($SIZE_MB MB)"; ./mkfile "$FILE" "$SIZE_MB" || die "mkfile failed"
fi

PIN=""
if [ -n "$CPUS" ]; then command -v taskset >/dev/null || die "taskset not found"; PIN="taskset -c $CPUS"; fi

STAMP=$(date +%Y%m%d_%H%M%S)
OUT=$OUTROOT/m3_studyb_$STAMP
mkdir -p "$OUT/runs" "$OUT/warmup"
[ "$SAVE_RAW" = "1" ] && mkdir -p "$OUT/raw"
cp "$CALIB" "$OUT/"; [ -f loads.conf ] && cp loads.conf "$OUT/"
[ -f "$INFO" ] && cp "$INFO" "$OUT/"; [ -f "$PHASES" ] && cp "$PHASES" "$OUT/studyb_phases.csv"

# ---- 2. environment record
{
  echo "=== Study B, Milestone 3 (task 3.6, Medur) ==="
  echo "date=$(date)"; echo "host=$(hostname)"; echo "kernel=$(uname -r)"
  echo "gcc=$(g++ --version | head -1)"
  echo "trace=$TRACE requests=$NREQ sha256_before=$SHA0"
  echo "file=$FILE size_mb=$SIZE_MB depth=$DEPTH direct=$DIRECT window_ms=$WINDOW_MS cpus=${CPUS:-none}"
  echo "reps=$REPS warmup_s=$WARMUP_S spins_us=$S1,$S2,$S3 adapt_args=${ADAPT_ARGS:-none}"
  echo "run_bench_sha256=$(sha256sum run_bench | cut -d' ' -f1)"
  git rev-parse HEAD 2>/dev/null | sed 's/^/git_commit=/' || true
  echo "--- load at start ---"; uptime
  echo "--- cpu ---"; lscpu 2>/dev/null | head -20
  echo "--- disk under DATADIR ---"; df -hT "$DATADIR"
} > "$OUT/environment.txt" 2>&1

# label | policy number | run_bench options
VARIANTS=(
  "wait|1|--policy wait"
  "poll|2|--policy poll"
  "spin${S1}|3|--policy spin --spin_us $S1"
  "spin${S2}|3|--policy spin --spin_us $S2"
  "spin${S3}|3|--policy spin --spin_us $S3"
  "adaptive|4|--policy adaptive --calib $CALIB"
)
NV=${#VARIANTS[@]}
FAILED=0
echo "label,policy,rep,order,exit_code" > "$OUT/run_order.csv"
echo "Study B (M3): $NV variants x $REPS reps, $NREQ requests each, warm-up ${WARMUP_S}s, cpu set ${CPUS:-any}"
echo "Output: $OUT"

for ((r = 1; r <= REPS; r++)); do
    # ---- 3a. warm-up (thrown away)
    if [ "$WARMUP_S" != "0" ]; then
        echo "--- rep $r: warm-up ($WARMUP_S s of the trace, policy wait, not used) ---"
        $PIN ./run_bench --file "$FILE" --trace "$TRACE" --depth "$DEPTH" --direct "$DIRECT" --policy wait \
             --stop_after_s "$WARMUP_S" > "$OUT/warmup/warmup_rep$r.txt" 2>&1 || true
    fi
    # ---- 3b. every policy, order rotated by one per repetition
    for ((i = 0; i < NV; i++)); do
        IFS='|' read -r L P ARGS <<< "${VARIANTS[$(((i + r - 1) % NV))]}"
        TAG="${L}_rep$r"
        EXTRA=""
        [ "$L" = "adaptive" ] && EXTRA="--adapt_log $OUT/runs/adapt_log_$TAG.csv --acct_log $OUT/runs/acct_log_$TAG.csv $ADAPT_ARGS"
        RAW=""; [ "$SAVE_RAW" = "1" ] && RAW="--out $OUT/raw/run_$TAG.csv"
        echo "=== rep $r, #$((i + 1)): $L (policy $P) ==="
        # shellcheck disable=SC2086
        $PIN ./run_bench --file "$FILE" --trace "$TRACE" --depth "$DEPTH" --direct "$DIRECT" \
             --timeline "$OUT/runs/timeline_$TAG.csv" --window_ms "$WINDOW_MS" $RAW $ARGS $EXTRA \
             > "$OUT/runs/summary_$TAG.txt" 2>&1
        RC=$?
        echo "$L,$P,$r,$((i + 1)),$RC" >> "$OUT/run_order.csv"
        grep -E "^(requests|errors|verify failures|response p50|CPU time per read|adaptive|allowance|probes)" "$OUT/runs/summary_$TAG.txt" | sed 's/^/    /'
        [ $RC -ne 0 ] && { echo "    ** run failed (exit $RC), see summary_$TAG.txt"; FAILED=$((FAILED + 1)); }
    done
done

# ---- 4. the trace must not have changed
SHA1=$(sha256sum "$TRACE" | cut -d' ' -f1)
echo "sha256_after=$SHA1" >> "$OUT/environment.txt"
echo "--- load at end ---" >> "$OUT/environment.txt"; uptime >> "$OUT/environment.txt"
[ "$SHA0" = "$SHA1" ] || { echo "ERROR: trace changed during the study"; FAILED=$((FAILED + 1)); }

# ---- 5. tables
./summarize_studyb_m3.sh "$OUT" "$NREQ" | tee "$OUT/studyb_summary.txt"

echo
if [ $FAILED -eq 0 ]; then echo "Study B done, all runs ok. Results in $OUT"; else echo "Study B done with $FAILED problem(s). Results in $OUT"; fi
echo "Next: ./package_m3_medur.sh $OUT"
[ $FAILED -eq 0 ]
