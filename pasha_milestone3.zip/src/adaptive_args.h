// adaptive_args.h - read policy 4 settings from named numbers (calibration.conf keys or command-line keys).
// Shared by run_bench (single run) and studya (task 3.5), so both set the controller the same way.
#pragma once
#include <stdexcept>

#include "adaptive_controller.h"

// get(key, default) must return the number for key, or the default when it was not given.
template <class Get>
inline AdaptiveConfig adaptive_config_from(Get get) {
    AdaptiveConfig ac;
    ac.budgets_ns[1] = static_cast<int64_t>(get("spin_short_us", get("short_us", 115)) * 1000.0);
    ac.budgets_ns[2] = static_cast<int64_t>(get("spin_mid_us", get("mid_us", 135)) * 1000.0);
    ac.budgets_ns[3] = static_cast<int64_t>(get("spin_long_us", get("long_us", 145)) * 1000.0);
    ac.window_ns = static_cast<int64_t>(get("ctl_window_ms", 10) * 1e6);
    ac.allowance = get("allowance_pct", 25) / 100.0;
    ac.min_spins = static_cast<int>(get("min_spins", ac.min_spins));
    ac.up_hit = get("up_hit", ac.up_hit);
    ac.down_hit = get("down_hit", ac.down_hit);
    ac.up_patience = static_cast<int>(get("up_patience", ac.up_patience));
    ac.cooldown = static_cast<int>(get("cooldown", ac.cooldown));
    ac.headroom = get("headroom", ac.headroom);
    ac.start_level = static_cast<int>(get("start_level", ac.start_level));
    ac.probe_every = static_cast<int>(get("probe_every", ac.probe_every));
    if (!(ac.budgets_ns[1] > 0 && ac.budgets_ns[1] < ac.budgets_ns[2] && ac.budgets_ns[2] < ac.budgets_ns[3]))
        throw std::runtime_error("adaptive budgets must be increasing and above zero");
    if (ac.start_level < 0 || ac.start_level > 3) throw std::runtime_error("start_level must be 0 to 3");
    return ac;
}
