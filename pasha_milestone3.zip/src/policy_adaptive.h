// policy_adaptive.h - policy 4: adaptive spin budget (plan task 3.1, Pasha).
//
// The I/O path is the same as policy 3 (peek for at most the budget, then sleep for the rest), so any
// difference in results comes from the controller in adaptive_controller.h, not from new I/O code.
// The policy keeps one window of counters, and at the end of each window gives them to the controller,
// which picks the budget for the next window.
//
// STAND-INS that are other owners' tasks and will be replaced when their versions are joined in:
//   * the CPU allowance check below (stop starting new spins once the window's allowance is used) = Medur 3.2
//   * the bounded probe at a zero budget                                                         = Medur 3.3
// Both are small on purpose so policy 4 runs end to end for testing.
#pragma once
#include <cerrno>

#include "adaptive_controller.h"
#include "common.h"
#include "harness_state.h"
#include "policy_wait.h"

inline AdaptiveConfig g_adapt_cfg;       // set before the run (run_bench reads it from the config)
inline AdaptiveController g_ctl;
inline WindowStats g_win;
inline uint64_t g_win_start_ns = 0;
inline uint64_t g_win_index = 0;
inline int g_win_probes_left = 0;

inline void adaptive_reset() {
    g_ctl.reset(g_adapt_cfg);
    g_win = WindowStats();
    g_win_start_ns = 0;
    g_win_index = 0;
    g_win_probes_left = 0;
    g_budget_ns = g_ctl.budget_ns();
}

inline void adaptive_close_window(uint64_t now) {
    g_ctl.update(g_win, now);
    g_budget_ns = g_ctl.budget_ns();  // the over-time recorder (timeline.h) reads this
    g_win = WindowStats();
    g_win_start_ns = now;
    g_win_index++;
    const bool probing_window = g_ctl.level() == 0 && g_adapt_cfg.probe_every > 0 &&
                                (g_win_index % static_cast<uint64_t>(g_adapt_cfg.probe_every)) == 0;
    g_win_probes_left = probing_window ? g_adapt_cfg.probes_per_window : 0;
}

// Spin for at most budget ns (bounded by the timeout). Returns true and fills *cqe on a hit.
inline bool adaptive_spin(struct io_uring* ring, struct io_uring_cqe** cqe, int64_t budget, uint64_t* used_ns) {
    const uint64_t t0 = now_ns();
    while (static_cast<int64_t>(now_ns() - t0) < budget) {
        int r = io_uring_peek_cqe(ring, cqe);
        if (r == 0) {
            *used_ns = now_ns() - t0;
            return true;
        }
        if (r != -EAGAIN) break;
    }
    *used_ns = now_ns() - t0;
    return false;
}

inline int policy_adaptive_wait(struct io_uring* ring, struct io_uring_cqe** cqe, int64_t timeout_ns) {
    *cqe = nullptr;
    const uint64_t t_in = now_ns();
    if (g_win_start_ns == 0) g_win_start_ns = t_in;
    if (static_cast<int64_t>(t_in - g_win_start_ns) >= g_adapt_cfg.window_ns) adaptive_close_window(t_in);

    if (g_inflight == 0) return policy_wait_immediately(ring, cqe, timeout_ns);  // nothing to spin for

    int64_t budget = g_ctl.budget_ns();
    bool probe = false;
    if (budget == 0 && g_win_probes_left > 0) {  // stand-in for task 3.3
        budget = g_adapt_cfg.budgets_ns[g_adapt_cfg.probe_level];
        probe = true;
        g_win_probes_left--;
    }
    // stand-in for task 3.2: no new spin once this window's allowance is spent
    if (!probe && static_cast<int64_t>(g_win.spin_ns) >= g_ctl.allowance_ns()) budget = 0;
    if (timeout_ns >= 0 && timeout_ns < budget) budget = timeout_ns;

    if (budget > 0) {
        uint64_t used = 0;
        const bool hit = adaptive_spin(ring, cqe, budget, &used);
        g_win.spin_ns += used;
        if (probe) {
            g_win.probes++;
            if (hit) g_win.probe_hits++;
        } else {
            g_win.spins++;
            if (hit) g_win.hits++;
        }
        if (hit) return 0;
    }
    int64_t rest = -1;
    if (timeout_ns >= 0) {
        rest = timeout_ns - static_cast<int64_t>(now_ns() - t_in);
        if (rest < 0) rest = 0;
    }
    return policy_wait_immediately(ring, cqe, rest);
}

inline const Policy kPolicyAdaptive = {"adaptive", policy_adaptive_wait};
